# Environment
IntelliJ IDEA 2024.3

MySQL 5.2

Java JDK-23


# Database
### Establish a data source
Datasource driver:
```
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
```

Datasource name:
```
spring.datasource.name=defaultDataSource
```
Datasource.url:
```
spring.datasource.url=jdbc:mysql://localhost:3306/storedb?useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai
```
Datasource username and password:
```
spring.datasource.username=root

spring.datasource.password=123456
```
### Establish a database
Run the file to establish a database:
```
store-DDL.sql
```

# Back-End
Run the file to establish the backend
```
src/main/java/cn/seu/store/StoreApplication.java
```

Properties and configuration settings for Spring Boot applications:
```
src/main/resources/application.properties
```

# Front-End
The frontend file is located at
```
src/main/resources/static/web
```

Login page
```
localhost:8080/web/login.html
```
Register page
```
localhost:8080/web/register.html
```
Home page
```
localhost:8080/web/index.html
```







