var cartListUrl="/carts/findByCids";
var addrListUrl="/addresses/list";
$(function(){
    var vueObj=new Vue({
        el: '#infoBody',
        data:{
            addrs:[],
            carts:[],
            totalNum:0,
            totalPrice:0
        }
    });
    // 为结算按钮添加点击事件
    $("#btn-pay").bind("click",function(){
        createOrder();
    });
    // 获取地址数据
    $.get(addrListUrl,function(result){
        if(result.state==1000){
            vueObj.addrs=result.data;
        }else{
            alert(result.msg);
        }
    });
    // 获取地址栏中的请求参数
    var map=getPathParams();
    var cids=map.get("cids");
    var params={
        cids:cids
    }
    // 获取购物车数据
    $.get(cartListUrl,params,function(result){
        if(result.state==1000){
            vueObj.carts=result.data;
            var totalNum=0;
            var totalPrice=0;
            // 计算总数量和总金额
            for(var index in result.data){
                totalNum+=result.data[index].num;
                totalPrice+=(result.data[index].num*result.data[index].realPrice);
            }
            vueObj.totalNum=totalNum;
            vueObj.totalPrice=totalPrice;
        }else {
            alert(result.msg);
        }
    });
});

var createOrderUrl="/orders/create";
// 发送创建订单请求的方法
function createOrder(){
    var aid=$("#selAddr option:selected").val();
    console.log("aid="+aid);
    var cids=getPathParams().get("cids");
    var params={
        aid:aid,
        cids:cids
    }
    $.post(createOrderUrl,params,function(result){
        if(result.state==1000){
            //window.location.href="orders.html";
            window.location.href = `payment.html?oid=${result.data}`;
        }else{
            alert(result.msg);
        }
    });
}

// 获取地址栏中所有参数构成的Map集合
function getPathParams(){
    var map=new Map();
    // 获取地址栏中的id参数
    var path=window.location.href;
    var index=path.lastIndexOf("?");
    if(index!=-1){
        var params=path.substring(index+1);
        var array=params.split("&");
        if(array.length>0){
            for(var index in array){
                var arr=array[index].split("=");
                // 将一组参数存入map集合
                map.set(arr[0],arr[1]);
            }
        }
    }
    return map;
}

// 文件原有js代码
$(function() {
	$(".link-pay").click(function() {
		location.href = "payment.html";
	})
})
$(function() {
	$(".link-success").click(function() {
		location.href = "paySuccess.html";
	})
})