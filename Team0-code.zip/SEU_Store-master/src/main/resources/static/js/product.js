function initButton(productNum, productStatus) {
	/*商品小图片加鼠标移入加边框、移出移除边框*/
	$(".img-small").hover(function() {
			$(this).css("border", "1px solid #4288c3");
		},
		function() {
			$(this).css("border", "");
		})
	//点击时变化大图片
	$(".img-small").click(function() {
			//获得点击的小图片数据
			var n = $(this).attr("data");
			//所有大图隐藏
			$(".img-big").hide();
			//显示点击的小图对应的大图
			$(".img-big[data='" + n + "']").show();
	})
	if (productNum >= 1 && productStatus == 1) {
		var n = parseInt($("#num").val());
		$("#numDown").attr("disabled", (n <= 1));
		$("#numUp").attr("disabled", (n >= productNum));
		//购物数量加1
		$("#numUp").click(function() {
			var n = parseInt($("#num").val());
			$("#num").val(n + 1);
			$("#numDown").attr("disabled", false);
			$("#numUp").attr("disabled", (n + 1 >= productNum));
		})
		//购物数量-1
		$("#numDown").click(function() {
			var n = parseInt($("#num").val());
			$("#num").val(n - 1);
			$("#numDown").attr("disabled", (n - 1 <= 1));
			$("#numUp").attr("disabled", false);
		})
	} else {
		$("#num").val(0);
		$("#numDown").attr("disabled", true);
		$("#numUp").attr("disabled", true);
	}
	
	//点购物车跳页面
	/*$(".go-cart").click(function() {
		location.href = "cart.html";
	});*/
	$(".img-big:eq(0)").show();
}