var findInfoUrl="/users/findDetailUserInfo";
var changeInfoUrl="/users/changeInfo";
var oldParams={};

$(function(){ // 页面就绪事件
    // 发送AJAX请求，获取用户信息
    $.get(findInfoUrl,function(result){
        var userInfo=result.data;
        // 回填表单数据
        $("#infoUsername").val(userInfo.username);
        if(userInfo.phone==null){
            $("#phone").prop("placeholder","首次设置");
        }else{
            $("#phone").val(userInfo.phone);
        }
        if(userInfo.email==null){
            $("#email").prop("placeholder","首次设置");
        }else{
            $("#email").val(userInfo.email);
        }
        if(userInfo.gender==0){
            $("#gender-f")[0].checked=true;
        }else{
            $("#gender-m")[0].checked=true;
        }
        // 填充oldParams
        oldParams.phone=userInfo.phone;
        oldParams.email=userInfo.email;
        oldParams.gender=userInfo.gender;
    });

    // 为手机号绑定验证逻辑
    $("#phone").bind("input",function(){
        checkPhone("phone","请输入正确的手机号");
    })

    $("#email").bind("input",function(){
        checkEmail("email","邮箱格式不正确");
    })

    // 为提交按钮添加点击事件
    $("#btnSubmit").click(function(){
        // 获取表单数据
        var phone=$("#phone").val();
        var email=$("#email").val();
        var gender=$('input[name="gender"]:checked').val();
        if(gender=='男'){
            gender=1;
        }else{
            gender=0;
        }
        // 没有更新则不提交
        if(oldParams.phone==phone && oldParams.email==email && oldParams.gender==gender){
            alert("本次未更新任何内容");
            return;
        }

        // 两次密码一致
        var flag=checkPhone("phone","请输入正确的手机号");
        flag=checkEmail("email","邮箱格式不正确")&&flag;

        // 有验证异常则不提交表单
        if(flag==false){
            return;
        }

        // 提交表单
        var params={
            phone:phone,
            email:email,
            gender:gender
        }
        // 发送AJAX请求
        $.post(changeInfoUrl,params,function(result){
            // 处理响应数据
            if(result.state==1000){ // 正常响应
                alert("信息修改成功");
            }else{ // 异常响应
                alert(result.msg);
            }
        });
    });
});