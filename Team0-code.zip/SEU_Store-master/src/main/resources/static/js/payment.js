var getOrderUrl="/orders/getByOid";
var alipayUrl="/payments/alipay";

var payVue = new Vue({
    el: '#payInfo',
    data: {
        oid: 0,
        totalPrice: 0
    }
});

var checkOrderStatusInterval = 3000;
var checkOrderStatusStarted = false;

$(function(){
    checkOrderStatusStarted = false;

    var map = getPaymentUrlParams();
    var oid = map.get("oid");
    var params = { oid: oid };
    $.post(getOrderUrl,params,function(result){
        if(result.state==1000) {
            var order = result.data;
            payVue.oid = order.id;
            payVue.totalPrice = order.totalPrice;
        }else{
            alert(result.msg);
        }
    });

    initPayButton();
});

function initPayButton() {
    $("#payButton").click(function() {
        //$(this).attr("value","支付中...");
        //$(this).attr("disabled","true");
        var params = { oid: payVue.oid };
        $.post(alipayUrl,params,function(result){
            if(result.state==1000){
                console.log("Submitting to AliPay...");
                var alipayWin = window.open();
                alipayWin.document.write(result.data);
                if (!checkOrderStatusStarted) {
                    setInterval(checkOrderStatus, checkOrderStatusInterval);
                    checkOrderStatusStarted = true;
                }
            }else{
                alert(result.msg);
                $("#payButton").attr("value","确认付款");
                $("#payButton").attr("disabled","false");
            }
        });
    });
}

function checkOrderStatus() {
    var params = { oid: payVue.oid };
    $.post(getOrderUrl,params,function(result){
        if(result.state==1000) {
            var order = result.data;
            if (order.status != 0) {
                clearInterval(checkOrderStatus);
                location.href = `payResult.html?oid=${payVue.oid}&status=${order.status}`;
            }
        }else{
            alert(result.msg);
        }
    });
}

// 获取地址栏中所有参数构成的Map集合
function getPaymentUrlParams(){
    var map=new Map();
    // 获取地址栏中的id参数
    var path=window.location.href;
    var index=path.lastIndexOf("?");
    if(index!=-1){
        var params=path.substring(index+1);
        var array=params.split("&");
        if(array.length>0){
            for(var index in array){
                var arr=array[index].split("=");
                // 将一组参数存入map集合
                map.set(arr[0],arr[1]);
            }
        }
    }
    return map;
}