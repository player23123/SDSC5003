var getOrderUrl="/orders/getByOid";

var orderVue = new Vue({
    el: '#payResultInfo',
    data: {
        oid: 0,
        totalPrice: 0,
        status: 0
    }
});

$(function(){
    var map = getPayResultUrlParams();
    var oid = map.get("oid");
    var orderStatus = map.get("status");
    var params = { oid: oid };
    $.post(getOrderUrl,params,function(result){
        if(result.state==1000) {
            var order = result.data;
            orderVue.oid = order.id;
            orderVue.totalPrice = order.totalPrice;
            orderVue.status = orderStatus;
        }else{
            alert(result.msg);
        }
    });
});

// 获取地址栏中所有参数构成的Map集合
function getPayResultUrlParams(){
    var map=new Map();
    // 获取地址栏中的id参数
    var path=window.location.href;
    var index=path.lastIndexOf("?");
    if(index!=-1){
        var params=path.substring(index+1);
        var array=params.split("&");
        if(array.length>0){
            for(var index in array){
                var arr=array[index].split("=");
                // 将一组参数存入map集合
                map.set(arr[0],arr[1]);
            }
        }
    }
    return map;
}