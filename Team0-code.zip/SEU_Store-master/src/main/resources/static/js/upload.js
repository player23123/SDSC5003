$(function(){
    var avatar=$.cookie("avatar");
    if (avatar == null) {
        avatar = sessionStorage.getItem("avatar");
    }
    $("#img-avatar").attr("src","/download/avatar?imageName="+avatar);
    $("#btnSubmit").click(function() {
        $.ajax({
            "url":"/users/changeAvatar",
            "data":new FormData($("#form-change-avatar")[0]),
            "type":"post",
            "contentType":false,
            "processData":false,
            "dataType":"json",
            "success":function(json) {
                // 服务器返回状态码200时触发
                if (json.state == 1000) {
                    alert("上传成功！");
                    $("#img-avatar").attr("src","/download/avatar?imageName="+json.data);
                    // 更新cookie中头像的路径
                    $.cookie("avatar",json.data,{"expires":7});
                    console.log(document.cookie);
                    // 更新session
                    sessionStorage.setItem("avatar", json.data);
                    console.log(sessionStorage.getItem("avatar"));
                    // 更新header
                    $("#avatar").attr("src","/download/avatar?imageName="+json.data);
                } else {
                    alert(json.msg);
                }
            },
            "error":function(json){
                // 响应状态不是1000时触发
                alert("登录状态失效，请重新登录！");
                // 页面重定向到login.html
                location.href="login.html";
            }
        });
    });
})