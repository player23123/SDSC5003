var queryByTypeUrl="/products/findProductByCid?cid=[cid]&currentPage=[currentPage]&pageSize=[pageSize]";
var queryByNameUrl="/products/findProductByName?name=[name]&currentPage=[currentPage]&pageSize=[pageSize]";
var addCartUrl="/carts/create";
var getCartByPidUrl="/carts/getCartByPid";
var removeCartUrl="/carts/remove";
var getFavoriteByPidUrl="/favorites/getFavoriteByPid";
var addFavoriteUrl="/favorites/create";
var removeFavoriteUrl="/favorites/delete";

var pageSize=12;
var cid=163;
var currentPage=1;
var map;

$(function(){
    map=getPathParams();
    if(map.get("currentPage")!=undefined){
        currentPage=map.get("currentPage");
    }

    initProdList();

    /*商品列表，鼠标移入时加阴影、移出移除阴影*/
	$(".goods-panel").hover(function() {
		$(this).css("box-shadow", "0px 0px 8px #888888");
	}, function() {
		$(this).css("box-shadow", "");
	})

    window.addEventListener("popstate", function(e) {
        initProdList();
    }, false);
});

function initProdList() {
    if(map.get("typeid")!=undefined){
        cid=map.get("typeid");
        queryByType();
    }else if(map.get("name")!=undefined){
        queryByName();
    }
}

function queryByName(){
    var typeName="";
    var name="";
    if(map.get("name")!=undefined){
        name=map.get("name");
    }

    var url=queryByNameUrl.replace("[name]",name)
                            .replace("[currentPage]",currentPage)
                            .replace("[pageSize]",pageSize);
    $.get(url,function(result){
        if(result.state==1000){
            // 获取jsonResult中的pageRecord中的data
            var data=result.data.data;
            var lineDataArray=[]; // 行数据的数组，元素是lineData
            var lineData=[]; // 数据数组，元素是prod对象，表示一行的4条记录
            var counter=0; // 计数器
            for(var index in data){ // 便利查询到的数据
                lineData.push(data[index]);
                counter++; // 计数器+1
                if(counter%4==0){ // 已添加4条记录
                    lineDataArray.push(lineData); // 将一行记录添加到数组中
                    lineData=[]; // 清空容器
                }
            }
            // 处理最后一行记录
            if(lineData.length!=0){ // lineData中有未添加的记录
                lineDataArray.push(lineData);
            }
            new Vue({
                el: '#prod-list',
                data:{
                    lineDatas:lineDataArray,
                    pageCount:result.data.pageCount,
                    name:name,
                    currentPage:currentPage,
                    nextPagePath:"search.html?name="+name+"&currentPage="+(parseInt(currentPage)+1),
                    prePagePath:"search.html?name="+name+"&currentPage="+(parseInt(currentPage)-1),
                    typeName:typeName,
                    searchPath:"search.html?name="+name
                }
            });
        }else{
            alert(result.msg);
            $("#prod-list").empty();
            $("#prod-list").html("<div class='col-md-offset-1 col-md-10'><img src='../images/not_found.jpg' class='img-responsive center-block'></div>");
        }
        initCartButton();
    });
}

function queryByType(){
    var typeName="";
    if(map.get("typename")!=undefined){
        typeName=unescape(map.get("typename"));
    }

    var url=queryByTypeUrl.replace("[cid]",cid)
                            .replace("[currentPage]",currentPage)
                            .replace("[pageSize]",pageSize);
    $.get(url,function(result){
        if(result.state==1000){
            // 获取jsonResult中的pageRecord中的data
            var data=result.data.data;
            var lineDataArray=[]; // 行数据的数组，元素是lineData
            var lineData=[]; // 数据数组，元素是prod对象，表示一行的4条记录
            var counter=0; // 计数器
            for(var index in data){ // 便利查询到的数据
                lineData.push(data[index]);
                counter++; // 计数器+1
                if(counter%4==0){ // 已添加4条记录
                    lineDataArray.push(lineData); // 将一行记录添加到数组中
                    lineData=[]; // 清空容器
                }
            }
            // 处理最后一行记录
            if(lineData.length!=0){ // lineData中有未添加的记录
                lineDataArray.push(lineData);
            }
            new Vue({
                el: '#prod-list',
                data:{
                    lineDatas:lineDataArray,
                    pageCount:result.data.pageCount,
                    typeid:cid,
                    currentPage:currentPage,
                    nextPagePath:"search.html?typeid="+cid+"&currentPage="+(parseInt(currentPage)+1),
                    prePagePath:"search.html?typeid="+cid+"&currentPage="+(parseInt(currentPage)-1),
                    typeName:typeName,
                    searchPath:"search.html?typeid="+cid
                }
            });
        }else{
            alert(result.msg);
            $("#prod-list").empty();
            $("#prod-list").html("<div class='col-md-offset-1 col-md-10'><img src='../images/not_found.jpg' class='img-responsive center-block'></div>");
        }
        // 初始化加入收藏按钮
        initHeartButton();
        // 初始化加入购物车按钮
        initCartButton();
    });
}

// 获取地址栏中所有参数构成的Map集合
function getPathParams(){
    var map=new Map();
    // 获取地址栏中的id参数
    var path=window.location.href;
    var index=path.lastIndexOf("?");
    if(index!=-1){
        var params=path.substring(index+1);
        var array=params.split("&");
        if(array.length>0){
            for(var index in array){
                var arr=array[index].split("=");
                // 将一组参数存入map集合
                map.set(arr[0],arr[1]);
            }
        }
    }
    return map;
}

function initHeartButton(){
    $(".add-fav").unbind("click");
    $(".add-fav").each(function(){
        var buttonObj = this;
        var pid = $(buttonObj).attr("pid");
        var params = { pid: pid }
        $.post(getFavoriteByPidUrl,params,function(result){
            if(result.state==1000){
                var favorite = result.data;
                if(favorite == null){ // 无收藏记录
                    $(buttonObj).html("<span class='fa fa-heart-o'></span>加入收藏");
                    bindAddFavoriteClick(buttonObj, pid);
                }else{
                    $(buttonObj).html("<span class='fa fa-heart'></span>取消收藏");
                    bindRemoveFavoriteClick(buttonObj, pid);
                }
            }else{
                alert(result.msg);
            }
        })
    });
}
function bindAddFavoriteClick(obj, pid){
    $(obj).bind("click", function(){
        var params={ product_id: pid }
        $.post(addFavoriteUrl,params,function(result){
            if(result.state==1000){
                alert("加入收藏成功");
                initProdList();
            }else{
                alert(result.msg);
            }
        });
    });
}
function bindRemoveFavoriteClick(obj, pid){
    $(obj).bind("click", function(){
        var params = { pid: pid }
        $.post(removeFavoriteUrl,params,function(result){
            if(result.state==1000){
                alert("取消收藏成功");
                initProdList();
            }else{
                alert(result.msg);
            }
        });
    });
}

function initCartButton(){
    $(".add-cart").unbind("click");
    $(".add-cart").each(function(){
        var buttonObj = this;
        var pid = $(buttonObj).attr("pid");
        var params = { pid: pid }
        $.post(getCartByPidUrl,params,function(result){
            if(result.state==1000){
                var cart = result.data;
                if(cart == null){ // 无购物车记录
                    $(buttonObj).html("<span class=\"fa fa-cart-arrow-down\"></span>加入购物车");
                    bindAddCartClick(buttonObj, pid);
                }else{
                    $(buttonObj).html("<span class=\"fa fa-close\"></span>从购物车中移除");
                    bindRemoveCartClick(buttonObj, cart.id);
                }
            }else{
                alert(result.msg);
            }
        })
    });
}

function bindAddCartClick(obj, pid) {
    $(obj).bind("click", function(){
        var params={
            product_id: pid,
            num: 1
        }
        $.post(addCartUrl,params,function(result){
            if(result.state==1000){
                alert("购物车添加成功");
                initProdList();
            }else{
                alert(result.msg);
            }
        });
    });
}
function bindRemoveCartClick(obj, cid) {
    $(obj).bind("click", function(){
        var params = { cid: cid }
        $.post(removeCartUrl,params,function(result){
            if(result.state==1000){
                alert("从购物车中移除成功");
                initProdList();
            }else{
                alert(result.msg);
            }
        });
    });
}