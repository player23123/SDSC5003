$(function(){
    var districtPath="/districts/";
    var defaultOption="<option value='0'>---- 请选择 ----</option>";

    var addressVue = new Vue ({
        el: '#addAddressForm',
        data: {
            aid: 0,
            name: "",
            provinceCode: "",
            cityCode: "",
            areaCode: "",
            zip: "",
            address: "",
            phone: "",
            tel: "",
            tag: ""
        }
    });

    $(function(){
        initAddressForm();

        // 为3个<select>添加默认选项
        $("#receiverState").empty();
        $("#receiverState").append(defaultOption);
        $("#receiverCity").empty();
        $("#receiverCity").append(defaultOption);
        $("#receiverDistrict").empty();
        $("#receiverDistrict").append(defaultOption);

        $("#receiverState").change(function(){
            var code=$("#receiverState").val();
            addDistrict(code, "receiverCity");
        });
        $("#receiverCity").change(function(){
            var code=$("#receiverCity").val();
            addDistrict(code,"receiverDistrict");
        });
        
        // 为表单提交按钮添加点击事件
        $("#btnSubmit").click(function(){
            $.ajax({
                "url":"/addresses/createAddress",
                "data":$("#addAddressForm").serialize(),
                "type":"post",
                "dataType":"json",
                "success":function(json) {
                    // 服务器返回状态码200时触发
                    if (json.state == 1000) {
                        alert("地址更新成功！");
                        location.href="address.html";
                    } else {
                        alert(json.msg);
                    }
                },
                "error":function(json){
                    // 响应状态不是1000时触发
                    alert("登录状态失效，请重新登录！");
                    // 页面重定向到login.html
                    location.href="login.html";
                }
            });
        });

    });

    function initAddressForm(){
        var getAddressUrl="/addresses/getAddressById";
        var map = getAddressUrlParams();
        var aid = map.get("aid");
        if (aid == null) {
            aid = 0;
        }
        var params = { aid: aid }
        $.post(getAddressUrl,params,function(result){
            if(result.state==1000){
                var address = result.data;
                if(address != null){
                    addressVue.aid = address.id;
                    addressVue.name = address.name;
                    addressVue.provinceCode = address.provinceCode;
                    addressVue.cityCode = address.cityCode;
                    addressVue.areaCode = address.areaCode;
                    addressVue.zip = address.zip;
                    addressVue.address = address.address;
                    addressVue.phone = address.phone;
                    addressVue.tel = address.tel;
                    addressVue.tag = address.tag;
                }
            }else{
                alert(result.msg);
            }
            // 初始化地区信息
            addDistrict("86","receiverState");
        })
    }
    // 获取地址栏中所有参数构成的Map集合
    function getAddressUrlParams(){
        var map=new Map();
        // 获取地址栏中的id参数
        var path=window.location.href;
        var index=path.lastIndexOf("?");
        if(index!=-1){
            var params=path.substring(index+1);
            var array=params.split("&");
            if(array.length>0){
                for(var index in array){
                    var arr=array[index].split("=");
                    // 将一组参数存入map集合
                    map.set(arr[0],arr[1]);
                }
            }
        }
        return map;
    }

    function addDistrict(parentCode,selectId){
        // 清空之前填充的内容
        $("#"+selectId).empty();
        if(parentCode=="0"){
            $("#"+selectId).append(defaultOption);
            return;
        }

        // 发送AJAX请求新的内容
        $.get(districtPath,{parent:parentCode},function(result){
            if(result.state==1000){ // 成功
                $("#"+selectId).append(defaultOption);
                for(var index in result.data){
                    var item=result.data[index];
                    var option="<option value='"+item.code+"'";
                    if (item.code == addressVue.provinceCode 
                            || item.code == addressVue.cityCode 
                            || item.code == addressVue.areaCode) {
                        console.log("selectedCode: " + item.code);
                        option += " selected";
                    }
                    option += ">"+item.name+"</option>";
                    $("#"+selectId).append(option);
                }
            }else{
                alert(result.msg);
            }
            if (selectId == "receiverState") {
                addDistrict($("#receiverState").val(),"receiverCity");
            } else if (selectId == "receiverCity") {
                addDistrict($("#receiverCity").val(),"receiverDistrict");
            }
        })
    }
});