var loginUrl="../users/login"

$(function(){ // 页面就绪事件
    $("#username").bind("input",function(){
        checkLength("username",6,12);
    });

    // 为密码输入框添加失去焦点事件
    $("#password").blur(function(){
        checkEmpty("password","密码不能为空");
    });

    // 为用户名输入框添加失去焦点事件
    $("#username").blur(function(){
        if(!checkEmpty("username","用户名不能为空")) {
            return;
        }
        if(!checkLength("username",6,12)) {
            return;
        }
    });

    // 为提交按钮添加点击事件
    $("#loginBtn").click(function(){
        // 获取表单数据
        var username=$("#username").val();
        var pwd=$("#password").val();

        // 判断页面中的input是否都是验证成功的状态
        var divArr=$("div.has-success");
        if(divArr.length!=2){ // 存在异常项
            return;
        }

        // 提交表单
        var params={
            username:username,
            password:pwd
        }
        // 发送AJAX请求
        $.post(loginUrl,params,function(result){
            // 处理响应数据
            if(result.state==1000){ // 正常响应
                var user = result.data;
                sessionStorage.setItem("avatar", user.avatar);
                console.log(user);
                alert("登录成功，点击跳转首页");
                // 跳转登录页面
                window.location.href="index.html";
            }else{ // 异常响应
                alert(result.msg);
            }
        });
    });
});

function checkLength(name,minLength,maxLength){
    if($("#"+name).val().length<minLength){ // 小于长度
        $("#"+name).parents(".form-group").addClass("has-error").removeClass("has-success");
        // 找到input相邻的span，在其中添加错误提示信息
        $("#"+name).next("span").text("长度不能小于"+minLength);
        return false;
    }else if($("#"+name).val().length>maxLength){
        $("#"+name).parents(".form-group").addClass("has-error").removeClass("has-success");
        // 找到input相邻的span，在其中添加错误提示信息
        $("#"+name).next("span").text("长度不能大于"+maxLength);
        return false;
    }else{ // 长度合适
        $("#"+name).parents(".form-group").removeClass("has-error").addClass("has-success");
        // 找到input相邻的span，在其中添加错误提示信息
        $("#"+name).next("span").text("");
        return true;
    }
}

function checkEmpty(name,msg){
    if($("#"+name).val()==""){ // 为空
        $("#"+name).parents(".form-group").addClass("has-error").removeClass("has-success");
        // 找到input相邻的span，在其中添加错误提示信息
        $("#"+name).next("span").text(msg);
        return false;
    }else{ // 不为空
        $("#"+name).parents(".form-group").removeClass("has-error").addClass("has-success");
        // 找到input相邻的span，在其中添加错误提示信息
        $("#"+name).next("span").text("");
        return true;
    }
}