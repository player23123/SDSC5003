var hotListUrl="/products/hot";
var favouriteUrl="/products/favourite";
var obj;
var favouriteObj;
$(function () {
    obj=new Vue({
        el: '#hot',
        data: {
            hots: []
        }
    });
    favouriteObj=new Vue({
        el: '#favourite',
        data: {
            favourites: []
        }
    });
    listHot();
    listFavourite();
});

function listHot(){
    $.get(hotListUrl,function(result){
        if(result.state==1000){
            obj.hots=result.data;
        }else{
            alert(result.msg);
        }
    });
}

function listFavourite(){
    $.get(favouriteUrl,function(result){
        if(result.state==1000){
            favouriteObj.favourites=result.data;
        }else{
            alert(result.msg);
        }
    });
}