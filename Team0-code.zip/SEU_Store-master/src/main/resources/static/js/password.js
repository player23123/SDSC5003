var changePasswordUrl="/users/changePassword"

$(function(){ // 页面就绪事件
    // 为提交按钮添加点击事件
    $("#btnSubmit").click(function(){
        // 获取表单数据
        var oldPwd=$("#oldPwd").val();
        var newPwd=$("#newPwd").val();
        var rePwd=$("#rePwd").val();

        var divArr=$("div.has-success");
        if(divArr.length!=3){ // 存在异常项
            return;
        }

        // 两次密码一致
        var flag=checkRePwd("newPwd","rePwd","两次密码应该一致");
        flag=checkNotSame("newPwd","oldPwd","新密码不能与旧密码一致")&&flag;

        // 有验证异常则不提交表单
        if(flag==false){
            return;
        }

        // 提交表单
        var params={
            oldPassword:oldPwd,
            newPassword:newPwd
        }
        // 发送AJAX请求
        $.post(changePasswordUrl,params,function(result){
            // 处理响应数据
            if(result.state==1000){ // 正常响应
                alert("密码修改成功");
                // 清空表单数据
                $("#oldPwd").val("");
                $("#newPwd").val("");
                $("#rePwd").val("");
            }else{ // 异常响应
                alert(result.msg);
            }
        });
    });
    // 为密码输入框添加失去焦点事件
    $("#oldPwd").blur(function(){
        checkEmpty("oldPwd","原始密码不能为空");
    });
    // 为密码输入框添加失去焦点事件
    $("#newPwd").blur(function(){
        checkEmpty("newPwd","新密码不能为空");
    });

    // 为用户名输入框添加失去焦点事件
    $("#rePwd").blur(function(){
        var notEmpty=checkEmpty("rePwd","确认密码不能为空");
        if(notEmpty){
            checkRePwd("newPwd","rePwd","两次密码不一致");
        }
    });
});

function checkEmpty(name,msg){
    if($("#"+name).val()==""){ // 为空
        $("#"+name).parents(".form-group").addClass("has-error").removeClass("has-success");
        // 找到input相邻的span，在其中添加错误提示信息
        $("#"+name).next("span").text(msg);
        return false;
    }else{ // 不为空
        $("#"+name).parents(".form-group").removeClass("has-error").addClass("has-success");
        // 找到input相邻的span，在其中添加错误提示信息
        $("#"+name).next("span").text("");
        return true;
    }
}

function checkRePwd(name,name2,msg){
    if($("#"+name).val()==""){ // 为空则不进行一致验证
        return false;
    }

    if($("#"+name).val()!=$("#"+name2).val()){ // 两次密码不一致
        $("#"+name2).parents(".form-group").addClass("has-error").removeClass("has-success");
        // 找到input相邻的span，在其中添加错误提示信息
        $("#"+name2).next("span").text(msg);
        return false;
    }else{ // 不为空
        $("#"+name2).parents(".form-group").removeClass("has-error").addClass("has-success");
        // 找到input相邻的span，在其中添加错误提示信息
        $("#"+name2).next("span").text("");
        return true;
    }
}

function checkNotSame(name,name2,msg){
    if($("#"+name).val()==""){ // 为空则不进行一致验证
        return false;
    }

    if($("#"+name).val()==$("#"+name2).val()){ // 两个内容一致
        $("#"+name2).parents(".form-group").addClass("has-error").removeClass("has-success");
        // 找到input相邻的span，在其中添加错误提示信息
        $("#"+name2).next("span").text(msg);
        return false;
    }else{ // 两个内容不一致
        $("#"+name2).parents(".form-group").removeClass("has-error").addClass("has-success");
        // 找到input相邻的span，在其中添加错误提示信息
        $("#"+name2).next("span").text("");
        return true;
    }
}