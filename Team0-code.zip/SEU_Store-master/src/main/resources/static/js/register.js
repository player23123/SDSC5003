var regUrl="/users/regist"
		$(function(){ // 页面就绪事件
			// 为提交按钮添加点击事件
			$("#btnSubmit").click(function(){
				// 获取表单数据
				var username=$("#username").val();
				var pwd=$("#pwd").val();
				var rePwd=$("#rePwd").val();
				// 前台表单验证
				var flag=true;
				// 非空验证
				flag=checkEmpty("username","用户名不能为空")&&flag;
				flag=checkEmpty("pwd","密码不能为空")&&flag;
				flag=checkEmpty("rePwd","确认密码不能为空")&&flag;

				// 格式验证
				// TODO 用户名：长度不低于6位
				// TODO 密码/确认密码：长度不低于8位，数字字母大小写组合

				// 判断页面中的input是否都是验证成功的状态
				var divArr=$("div.has-success");
				if(divArr.length!=3){ // 存在异常项
					return;
				}

				// 逻辑验证
				// 两次密码一致
				flag=checkRePwd("pwd","rePwd","两次密码应该一致")&&flag;

				// 用户名不存在 TODO

				// 有验证异常则不提交表单
				if(flag==false){
					return;
				}
				// 提交表单
				// 请求参数属性名:变量名
				// 请求参数属性名要和后台实体类的属性名一致
				var params={
					username:username,
					password:pwd
				}
				// 发送AJAX请求
				$.post(regUrl,params,function(result){
					// 处理响应数据
					if(result.state==1000){ // 正常响应
						alert("注册成功，点击跳转登录页面");
						// 跳转登录页面
						window.location.href="login.html";
					}else{ // 异常响应
						alert(result.msg);
					}
				});
			});

			$("#username").bind("input",function(){
				checkLength("username",6,12);
			});

			// 为用户名输入框添加失去焦点事件
			$("#username").blur(function(){
				if(!checkEmpty("username","用户名不能为空")) {
					return;
				}
				if(!checkLength("username",6,12)) {
					return;
				}
				// 异步验证用户名是否存在
				var url="../users/checkUsername";
				var params={
					username:$("#username").val()
				};
				$.get(url,params,function(result){
					if(result.state==1000 && result.msg=="false"){ // 不存在
						$("#username").parents(".form-group").removeClass("has-error").addClass("has-success");
						// 找到input相邻的span，在其中添加错误提示信息
						$("#username").next("span").text("该用户可以使用");
					}else if(result.state==1000 && result.msg=="true"){ // 已存在
						$("#username").parents(".form-group").addClass("has-error");
						// 找到input相邻的span，在其中添加错误提示信息
						$("#username").next("span").text("该用户名已存在");
					}else{
						$("#username").parents(".form-group").addClass("has-error");
						// 找到input相邻的span，在其中添加错误提示信息
						$("#username").next("span").text(result.msg);
					}
				});
			});

			// 为密码输入框添加失去焦点事件
			$("#pwd").blur(function(){
				checkEmpty("pwd","密码不能为空");
			});

			// 为用户名输入框添加失去焦点事件
			$("#rePwd").blur(function(){
				var notEmpty=checkEmpty("rePwd","确认密码不能为空");
				if(notEmpty){
					checkRePwd("pwd","rePwd","两次密码不一致");
				}
			});

		});

		function checkLength(name,minLength,maxLength){
			if($("#"+name).val().length<minLength){ // 小于长度
				$("#"+name).parents(".form-group").addClass("has-error").removeClass("has-success");
				// 找到input相邻的span，在其中添加错误提示信息
				$("#"+name).next("span").text("长度不能小于"+minLength);
				return false;
			}else if($("#"+name).val().length>maxLength){
				$("#"+name).parents(".form-group").addClass("has-error").removeClass("has-success");
				// 找到input相邻的span，在其中添加错误提示信息
				$("#"+name).next("span").text("长度不能大于"+maxLength);
				return false;
			}else{ // 长度合适
				$("#"+name).parents(".form-group").removeClass("has-error").addClass("has-success");
				// 找到input相邻的span，在其中添加错误提示信息
				$("#"+name).next("span").text("");
				return true;
			}
		}

		function checkEmpty(name,msg){
			if($("#"+name).val()==""){ // 为空
				$("#"+name).parents(".form-group").addClass("has-error").removeClass("has-success");
				// 找到input相邻的span，在其中添加错误提示信息
				$("#"+name).next("span").text(msg);
				return false;
			}else{ // 不为空
				$("#"+name).parents(".form-group").removeClass("has-error").addClass("has-success");
				// 找到input相邻的span，在其中添加错误提示信息
				$("#"+name).next("span").text("");
				return true;
			}
		}

		function checkRePwd(name,name2,msg){
			if($("#"+name).val()==""){ // 为空则不进行一致验证
				return false;
			}

			if($("#"+name).val()!=$("#"+name2).val()){ // 两次密码不一致
				$("#"+name2).parents(".form-group").addClass("has-error").removeClass("has-success");
				// 找到input相邻的span，在其中添加错误提示信息
				$("#"+name2).next("span").text(msg);
				return false;
			}else{ // 不为空
				$("#"+name2).parents(".form-group").removeClass("has-error").addClass("has-success");
				// 找到input相邻的span，在其中添加错误提示信息
				$("#"+name2).next("span").text("");
				return true;
			}
		}