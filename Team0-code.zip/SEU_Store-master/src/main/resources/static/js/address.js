var template="<tr>" +
    "<td>[tag]</td>" +
    "<td>[name]</td>" +
    "<td>[provinceName][cityName][areaName][address]</td>" +
    "<td>[phone]</td>" +
    "<td><a aid='[aid]' class='btn btn-xs btn-info btn-edit'><span class='fa fa-edit' ></span> 修改</a></td>" +
    "<td><a aid='[aid]' class='btn btn-xs add-del btn-info btn-delete'><span class='fa fa-trash-o' ></span> 删除</a></td>" +
    "<td><a aid='[aid]' class='btn btn-xs add-def btn-default'>设为默认</a></td>" +
    "</tr>";
var addressListUrl="/addresses/list";
$(function () {
    listAddr();
});

function listAddr(){
    $("#tbody").empty();
    $.get(addressListUrl,function(result){
        if(result.state==1000){
            for(var index in result.data){
                var addr=result.data[index];
                // js的replace默认仅替换第一个符合条件的内容
                var td=template.replace("[tag]",addr.tag)
                        .replace("[name]",addr.name)
                        .replace("[provinceName]",addr.provinceName)
                        .replace("[cityName]",addr.cityName)
                        .replace("[areaName]",addr.areaName)
                        .replace("[address]",addr.address)
                        .replace("[phone]",addr.phone)
                        .replace(/\[aid\]/g,addr.id); // 替换所有aid
                var tdObj=$(td);
                var btnDefault=tdObj.find(".btn-default");
                if(addr.isDefault==1){
                    btnDefault.remove();
                }
                $("#tbody").append(tdObj);
            }
        }else{
            alert(result.msg);
        }

        // 为btn-default按钮添加点击事件
        $(".btn-default").bind("click",function(){
            // 获取当前组件的aid属性的值
            // this -> js对象 表示的是当前方法的调用者
            var aid=$(this).attr("aid");
            // 发送AJAX请求设置默认地址
            var setDefaultUrl="/addresses/"+aid+"/set_default";
            $.post(setDefaultUrl,function(result){
                if(result.state==1000){
                    alert("默认地址设置成功");
                    // 刷新地址数据
                    listAddr();
                }else{
                    alert(result.msg);
                }
            });
        });
        // 为删除按钮添加点击事件
        $(".btn-delete").bind("click",function(){
            var flag=confirm("是否删除该地址");
            if(flag==false){ // 取消
                return;
            }
            // 获取当前组件的aid属性的值
            // this -> js对象 表示的是当前方法的调用者
            var aid=$(this).attr("aid");
            // 发送AJAX请求设置默认地址
            var deleteUrl="/addresses/"+aid+"/delete";
            $.post(deleteUrl,function(result){
                if(result.state==1000){
                    alert("删除地址成功");
                    // 刷新地址数据
                    listAddr();
                }else{
                    alert(result.msg);
                }
            });
        });
        // 为修改按钮添加点击事件
        $(".btn-edit").bind("click",function(){
            var aid = $(this).attr("aid");
            location.href=`addAddress.html?aid=${aid}`;
        });
    });
}