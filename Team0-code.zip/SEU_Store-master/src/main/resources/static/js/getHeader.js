var checkLoginUrl="/users/findUserInfo" // 获取用户信息的服务器接口
var headerSubPagePath="" // 用于保存页头子页面的路径
var userData; // 用于查询到的保存用户信息

// 获取用户登录信息
$.get(checkLoginUrl,function(result){
    // 用户未登录
    if(result.state==2004){
        headerSubPagePath="subpage_notLoggedIn.html"
    }else{ // 用户已登录
        headerSubPagePath="subpage_loggedIn.html"
        userData = result.data;
        userData.avatar=sessionStorage.getItem("avatar");
    }

    console.log("SubPage: " + headerSubPagePath);
    console.log(result.data);
    console.log(sessionStorage.getItem("avatar"));

    $(document).ready(function() {
        loadHeader();
    });
});

function loadHeader() {
    // 请求子页面并加载到当前页面中
    $("#header").load(headerSubPagePath, function(){
        console.log("Header load");

        // 如果存在用户信息，将信息填充到页面中
        if(userData!=undefined){
            // 获取用户名
            var username=userData.username;
            if(username!=undefined){
                if(username.length>6){
                    // 如果长度大于6位，将6位之后的内容用...替代
                    username=username.substring(0,6)+"...";
                }
                // 将用户名显示在页面中
                $("#username").html(username)
            }
            // 显示用户的头像
            if(userData.avatar!=undefined){
                $("#avatar").attr("src","/download/avatar?imageName="+userData.avatar);
            }else{
                $("#avatar").attr("src","/images/index/user.jpg");
            }
        }
    })
}