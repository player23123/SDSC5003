var orderListUrl="/orders/list";
var getOrderTimeoutUrl="/orders/getOrderTimeout";

var timerArray=[]; // 保存计时器的数组
var orderTimeout = 0;

$(function(){
    getOrderTimeout();

    Vue.filter("formatDate",function(value) {//这里的value就是需要过滤的数据
        var date = new Date(value);
        var year = date.getFullYear();
        var month = padDate(date.getMonth()+1);
        var day = padDate(date.getDate());
        var hours = padDate(date.getHours());
        var minutes = padDate(date.getMinutes());
        var seconds = padDate(date.getSeconds());
        //将整理好的数据返回出去
        return year+'-'+month+'-'+day+' ' +hours+':'+minutes+':'+seconds;
    });

    var vueObj=new Vue({
        el: '#orderListBody',
        data:{
            orders:[]
        }
    });
    // 在vue加载完页面后再调用initTimeout方法
    vueObj.$watch('orders',function(val) {
        vueObj.$nextTick(function () {
            initTimeout();
        });
    });
    $.get(orderListUrl,function(result){
        if(result.state==1000){
            vueObj.orders=result.data;
        }else{
            alert(result.msg);
        }
    })
})

var padDate = function (value) {
    return value<10 ? '0'+value : value;
};

function getOrderTimeout() {
    $.get(getOrderTimeoutUrl,function(result){
        if(result.state==1000){
            orderTimeout = result.data;
        }else{
            alert(result.msg);
        }
    });
}

function initTimeout(){
    var spanArr=$(".s-countdown");
    for(var index = 0; index < spanArr.length; index++){
        var dateStr=$(spanArr[index]).attr("ordertime");
        startTimer(new Date(dateStr),index,spanArr[index]);
    }
}

function startTimer(targetTime,index,spanObj){
    var nowtime = new Date();
    var time = targetTime - nowtime+(orderTimeout*60*1000);
    if(time<=0){ // 如果时间有问题，则不启动计时器
        $(spanObj).html("剩余：00:00");
        return;
    }
    var timer=setInterval(function () {
        var nowtime2 = new Date();
        var time2 = targetTime - nowtime2+(orderTimeout*60*1000);
        if(time2<=0){ // 倒计时结束
            $('.timespan').html("剩余：00:00");
            stopTimer(index);
            return;
        }
        // var day = padDate(parseInt(time2 / 1000 / 60 / 60 / 24));
        // var hour = padDate(parseInt(time2 / 1000 / 60 / 60 % 24));
        var minute = padDate(parseInt(time2 / 1000 / 60 % 60));
        var seconds = padDate(parseInt(time2 / 1000 % 60));
        $(spanObj).html("剩余："+minute + ":" + seconds);
    }, 1000);
    // 将计时器存入timer数组
    timerArray[index]=timer;
}

function stopTimer(index){
    var timer=timerArray[index];
    if(timer!=undefined){
        clearInterval(timer);
    }
}