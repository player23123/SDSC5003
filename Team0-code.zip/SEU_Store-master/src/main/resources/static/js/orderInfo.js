var getOrderUrl="/orders/getByOid";
var changeOrderStatusUrl="/orders/changeStatus";

var orderInfoVue = new Vue({
    el: '#orderInfo',
    data: {
        oid: 0,
        recvName: "",
        recvPhone: "",
        recvProvince: "",
        recvCity: "",
        recvArea: "",
        recvAddress: "",
        status: 0,
        totalPrice: 0,
        orderTime: "",
        payTime: "",
        modifiedTime: "",
        orderItems: []
    },
    watch : {
        status: {
            handler() {
                this.$nextTick(function() {
                    initReceiveButton();
                });
            },
            immediate: true
        }
    }
});

$(function(){
    initOrderInfo();
});
function initOrderInfo() {
    var map = getOrderInfoUrlParams();
    var oid = map.get("oid");
    getOrder(oid);
}

function getOrder(oid) {
    var params = { oid: oid };
    $.post(getOrderUrl,params,function(result){
        if(result.state==1000){
            var order = result.data;
            orderInfoVue.oid = order.id;
            orderInfoVue.recvName = order.recvName;
            orderInfoVue.recvPhone = order.recvPhone;
            orderInfoVue.recvProvince = order.recvProvince;
            orderInfoVue.recvCity = order.recvCity;
            orderInfoVue.recvArea = order.recvArea;
            orderInfoVue.recvAddress = order.recvAddress;
            orderInfoVue.status = order.status;
            orderInfoVue.totalPrice = order.totalPrice;
            orderInfoVue.orderTime = formatDate(order.orderTime);
            orderInfoVue.payTime = formatDate(order.payTime);
            orderInfoVue.modifiedTime = formatDate(order.modifiedTime);
            orderInfoVue.orderItems = order.orderItems;
        }else{
            alert(result.msg);
        }
    });
}
function formatDate(value) { // 过滤日期格式
    var date = new Date(value);
    var year = date.getFullYear();
    var month = padDate(date.getMonth()+1);
    var day = padDate(date.getDate());
    var hours = padDate(date.getHours());
    var minutes = padDate(date.getMinutes());
    var seconds = padDate(date.getSeconds());
    return year+'-'+month+'-'+day+' '+hours+':'+minutes+':'+seconds;
}
function padDate(value) {
    return value < 10 ? '0' + value : value;
}

function initReceiveButton() {
    $("#receiveButton").unbind("click");
    $("#receiveButton").click(function(){
        if(!confirm("确认收货吗？")){
            return;
        }
        var params = {
            oid: orderInfoVue.oid,
            status: 4
        }
        $.post(changeOrderStatusUrl,params,function(result){
            if(result.state==1000){
                alert("已确认收货")
                initOrderInfo();
            }else{
                alert(result.msg);
            }
        });
    });
}

// 获取地址栏中所有参数构成的Map集合
function getOrderInfoUrlParams(){
    var map=new Map();
    // 获取地址栏中的id参数
    var path=window.location.href;
    var index=path.lastIndexOf("?");
    if(index!=-1){
        var params=path.substring(index+1);
        var array=params.split("&");
        if(array.length>0){
            for(var index in array){
                var arr=array[index].split("=");
                // 将一组参数存入map集合
                map.set(arr[0],arr[1]);
            }
        }
    }
    return map;
}