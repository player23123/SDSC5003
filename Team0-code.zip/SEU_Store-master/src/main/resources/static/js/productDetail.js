var addCartUrl="/carts/create";
var getCartByPidUrl="/carts/getCartByPid";
var removeCartUrl="/carts/remove";
var addFavoriteUrl="/favorites/create";
var getFavoriteByPidUrl="/favorites/getFavoriteByPid";
var removeFavoriteUrl="/favorites/delete";

var product;

$(function(){
    initProdInfo();
});
function initProdInfo() {
    // 获取地址栏中的id参数
    var path=window.location.href;
    var index=path.lastIndexOf("?");
    var id=10000001;
    if(index!=-1){
        var params=path.substring(index+1);
        var array=params.split("&");
        if(array[0].startsWith("id=")){
            id=array[0].split("=")[1];
        }
    }
    var prodUrl="../products/"+id+"/get";
    $.get(prodUrl,function(result){
        if(result.state==1000){
            product = result.data;
            console.log(product);
            new Vue({
                el: '#product-detail',
                data: product
            });
            initButton(product.num, product.status);
            initAnimate();
            // 初始化添加购物车按钮
            initCartButton();
            // 初始化收藏按钮
            initHeartButton();
            // 初始化立即购买按钮
            initBuyNowButton();
        }else{
            alert(result.msg);
        }
    });
}

function bindAddCartClick(obj, pid, num) {
    $(obj).bind("click", function(){
        var params={
            product_id: pid,
            num: num
        }
        $.post(addCartUrl,params,function(result){
            if(result.state==1000){
                alert("购物车添加成功");
                initProdInfo();
            }else{
                alert(result.msg);
            }
        });
    });
}
function bindRemoveCartClick(obj, cid) {
    $(obj).bind("click", function(){
        var params = { cid: cid }
        $.post(removeCartUrl,params,function(result){
            if(result.state==1000){
                alert("从购物车中移除成功");
                initProdInfo();
            }else{
                alert(result.msg);
            }
        });
    });
}
function initCartButton(){
    $("#addCart").unbind("click");
    if (product.status != 1) {
        $("#addCart").attr("disabled", true);
        return;
    }

    var params = { pid: product.id }
    $.post(getCartByPidUrl,params,function(result){
        if(result.state==1000){
            var cart = result.data;
            if(cart == null){ // 无购物车记录
                $("#addCart").html("<span class=\"fa fa-cart-plus\"></span> 加入购物车");
                var num = $("#num").val();
                bindAddCartClick("#addCart", product.id, num);
            }else{
                $("#addCart").html("<span class=\"fa fa-close\"></span> 从购物车中移除");
                bindRemoveCartClick("#addCart", cart.id);
            }
        }else{
            alert(result.msg);
        }
    });
}

function initBuyNowButton(){
    $("#buyNow").unbind("click");
    if (product.status != 1) {
        $("#buyNow").attr("disabled", true);
        $("#buyNow").val("商品已下架");
        return;
    }

    var params = { pid: product.id }
    $.post(getCartByPidUrl,params,function(result){
        if(result.state==1000){
            var cart = result.data;
            bindBuyNowClick(cart == null);
        }else{
            alert(result.msg);
        }
    });
}
function bindBuyNowClick(cartIsNull){
    $("#buyNow").click(function(){
        if(cartIsNull){
            var num=$("#num").val();
            var params={
                product_id: product.id,
                num: num
            }
            $.post(addCartUrl,params,function(result){
                if(result.state==1000){
                    location.href = "cart.html";
                }else{
                    alert(result.msg);
                }
            })
        }else{
            location.href = "cart.html";
        }
    });
}

function initHeartButton(){
    $("#heart").unbind("click");
    if (product.status != 1) {
        $("#heart").attr("disabled", true);
        return;
    }

    var params = { pid: product.id }
    $.post(getFavoriteByPidUrl,params,function(result){
        if(result.state==1000){
            var favorite = result.data;
            if(favorite == null){
                $("#heart").html("<span class=\"fa fa-heart-o\"></span> 加入收藏");
                bindAddFavoriteClick("#heart", product.id);
            }else{
                $("#heart").html("<span class=\"fa fa-heart\"></span> 取消收藏");
                bindRemoveFavoriteClick("#heart", product.id);
            }
        }else{
            alert(result.msg);
        }
    });
}
function bindAddFavoriteClick(obj, pid){
    $(obj).bind("click", function(){
        var params={ product_id: pid }
        $.post(addFavoriteUrl,params,function(result){
            if(result.state==1000){
                alert("加入收藏成功");
                initProdInfo();
            }else{
                alert(result.msg);
            }
        });
    });
}
function bindRemoveFavoriteClick(obj, pid){
    $(obj).bind("click", function(){
        var params = { pid: pid }
        $.post(removeFavoriteUrl,params,function(result){
            if(result.state==1000){
                alert("取消收藏成功");
                initProdInfo();
            }else{
                alert(result.msg);
            }
        });
    });
}