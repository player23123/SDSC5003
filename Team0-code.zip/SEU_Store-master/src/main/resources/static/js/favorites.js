var favoriteListUrl="/favorites/list";
var deleteFavoriteUrl="/favorites/delete";
var addFavoriteUrl="/favorites/create";
var removeCartUrl="/carts/remove";
var addCartUrl="/carts/create";

var pageNum = 1;
var totalPage = 1;
var pageInfoVue = new Vue({
	el : '#pageInfo',
	data : {
		pageNum : pageNum,
		totalPage : totalPage
	}
});
var listVO = new Array();
listVO.push(new Array());
var listVOVue = new Vue({
	el : '#favoriteList',
	data : {
		listVO : listVO
	},
	watch : {
		listVO:  {
			handler() {
				this.$nextTick(function() {
					initGoodPanelShadow();
					initHeartButton();
					initCartButton();
				});
			},
			immediate: true
		}
	}
});

$(function() {
	initFavoriteList();
	initPrevPageButton();
	initNextPageButton();
})

function initFavoriteList() {
	$.get(favoriteListUrl,function(result){
		if(result.state==1000){
			$("#favoriteTitle").html("<b>我的收藏（共" + result.data.length.toString() + "件）：</b>");
			if (result.data.length % 12 == 0) {
				totalPage = parseInt(result.data.length / 12);
			} else {
				totalPage = parseInt(result.data.length / 12) + 1;
			}
			if (pageNum > totalPage) {
				pageNum = totalPage;
			}
			pageInfoVue.pageNum = pageNum;
			pageInfoVue.totalPage = totalPage;

			var listVO = getListVO(result.data);
			listVOVue.listVO = listVO;
		}else if(result.state==2004){ // 未找到记录
			alert("您还未收藏任何商品");
			$("#favoriteList").empty();
		}else{
			alert(result.msg);
			$("#favoriteList").empty();
		}
	})
}
function getListVO(list) {
	var baseIndex = (pageNum - 1) * 12;
	var listVO = new Array();
	listVO.push(new Array());
	var rowIndex = 0;
	for (var i = 0; i < 12; ++i) {
		var index = baseIndex + i;
		if (index >= list.length) {
			break;
		}
		listVO[rowIndex].push(list[index]);
		if (i + 1 % 4 == 0) {
			listVO.push(new Array());
		}
	}
	return listVO;
}

function initGoodPanelShadow() {
	$(".goods-panel").unbind("hover");
	/*商品列表，鼠标移入时加阴影、移出移除阴影*/
	$(".goods-panel").hover(function() {
		$(this).css("box-shadow", "0px 0px 8px #888888");
	}, function() {
		$(this).css("box-shadow", "");
	})
}
function initHeartButton() {
	$(".add-fav").unbind("click");
	$(".add-fav").click(function(){
		var pid = parseInt($(this).find($(".heart-pid")).text());
		var params = { pid: pid }
		$.post(deleteFavoriteUrl, params, function(result){
			console.log("Delete Favorite, Pid: " + pid.toString());
			if (result.state == 1000) {
				alert("取消收藏成功");
				initFavoriteList();
			} else {
				alert(result.msg);
			}
		})
	});
	/*
	"<span class='fa fa-heart-o'></span>加入收藏"
	"<span class='fa fa-heart'></span>取消收藏"
	 */
}
function initCartButton() {
	$(".add-cart").unbind("click");
	// TODO: 售罄处理
	$(".add-cart").click(function(){
		var cid = parseInt($(this).find($(".cart-cid")).text());
		var pid = parseInt($(this).find($(".cart-pid")).text());
		if (cid >= 0) { // in cart
			var params = { cid: cid }
			$.post(removeCartUrl, params, function(result) {
				console.log("Delete Cart, Cid: " + cid.toString());
				if (result.state == 1000) {
					alert("从购物车中移除成功");
					initFavoriteList();
				} else {
					alert(result.msg);
				}
			});
		} else {
			var params = { product_id: pid, num: 1 }
			$.post(addCartUrl, params, function(result){
				console.log("Add Cart, Pid: " + pid.toString());
				if (result.state == 1000) {
					alert("已加入购物车");
					initFavoriteList();
				} else {
					alert(result.msg);
				}
			});
		}
	});
}

function initPrevPageButton() {
	$("#prevPage").click(function(){
		if (pageNum > 1) {
			--pageNum;
		}
		initFavoriteList();
	});
}
function initNextPageButton() {
	$("#nextPage").click(function(){
		if (pageNum < totalPage) {
			++pageNum;
		}
		initFavoriteList();
	});
}