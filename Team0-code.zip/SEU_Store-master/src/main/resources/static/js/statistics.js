var getHistoryUrl = "/userOpt/getHistoryByUid";
var getMostPvUrl = "/userOpt/getMostPvProduct";
var getMostFavUrl = "/userOpt/getMostFavProduct";
var getMostCartUrl = "/userOpt/getMostCartProduct";
var getMostBuyUrl = "/userOpt/getMostBuyProduct";

var historyVue = new Vue ({
    el: '#historyListBody',
    data: {
        userOpts: []
    }
});
var trendVue = new Vue ({
    el: '#trendListBody',
    data: {
        mostPvProduct: null,
        mostFavProduct: null,
        mostCartProduct: null,
        mostBuyProduct: null
    }
});

$(function(){
    initHistoryList();
    initTrendList();
})

function initHistoryList() {
    $.get(getHistoryUrl, function(result){
        if(result.state==1000){
            historyVue.userOpts = result.data;
        }else{
            alert(result.msg);
        }
    });
}
function initTrendList() {
    $.get(getMostPvUrl, function(result){
        if(result.state==1000){
            trendVue.mostPvProduct = result.data;
            console.log(trendVue.mostPvProduct);
        }else{
            alert(result.msg);
        }
    });
    $.get(getMostFavUrl, function(result){
        if(result.state==1000){
            trendVue.mostFavProduct = result.data;
            console.log(trendVue.mostFavProduct);
        }else{
            alert(result.msg);
        }
    });
    $.get(getMostCartUrl, function(result){
        if(result.state==1000){
            trendVue.mostCartProduct = result.data;
            console.log(trendVue.mostCartProduct);
        }else{
            alert(result.msg);
        }
    });
    $.get(getMostBuyUrl, function(result){
        if(result.state==1000){
            trendVue.mostBuyProduct = result.data;
            console.log(trendVue.mostBuyProduct);
        }else{
            alert(result.msg);
        }
    });
}