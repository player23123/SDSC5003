package cn.seu.store.service;

import cn.seu.store.entity.Product;
import cn.seu.store.entity.UserOptVO;
import cn.seu.store.service.ex.RecordNotFoundException;

import java.util.List;

public interface IUserOptService {
    List<UserOptVO> getUserOptsByUid(Integer uid) throws RecordNotFoundException;

    Product getMostOptProduct(String type) throws RecordNotFoundException;
}
