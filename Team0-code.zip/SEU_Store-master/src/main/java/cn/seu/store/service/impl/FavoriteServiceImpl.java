package cn.seu.store.service.impl;

import cn.seu.store.entity.Favorite;
import cn.seu.store.entity.FavoriteVO;
import cn.seu.store.entity.Product;
import cn.seu.store.entity.User;
import cn.seu.store.entity.Cart;
import cn.seu.store.mapper.FavoriteMapper;
import cn.seu.store.service.ICartService;
import cn.seu.store.service.IFavoriteService;
import cn.seu.store.service.IProductService;
import cn.seu.store.service.IUserService;
import cn.seu.store.service.ex.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FavoriteServiceImpl implements IFavoriteService {
    @Autowired(required = false)
    FavoriteMapper mapper;

    @Autowired
    IUserService userService;

    @Autowired
    IProductService productService;

    @Autowired
    ICartService cartService;

    @Override
    public List<FavoriteVO> getFavoriteList(Integer uid) throws RecordNotFoundException {
        List<FavoriteVO> favoriteList = mapper.getFavoriteList(uid);
        if (favoriteList == null || favoriteList.size() == 0) {
            throw new RecordNotFoundException("查询收藏列表异常：未查到记录");
        }
        for (FavoriteVO fVO : favoriteList) {
            Cart cart = cartService.getCartByUidAndPid(uid, fVO.getPid());
            fVO.setCid(cart == null ? -1 : cart.getId());
        }
        return favoriteList;
    }

    @Override
    public void createFavorite(Integer productId, Integer userId, String username)
            throws RecordNotFoundException, UpdateException, InsertException {
        // 验证user_id对应的用户数据是否存在
        User user=userService.findById(userId);
        if(user==null || user.getIsDelete()==1){
            throw new RecordNotFoundException("添加收藏异常：用户信息不存在");
        }
        // 基于商品id查询商品数据
        // 判断结果是否为null
        // 是：RecordNotFoundException
        // 判断商品的status是否不为1
        // 是：RecordNotFoundException -> 已下架
        Product product=productService.findByIdInner(productId);
        if(product==null || product.getStatus()!=1){
            throw new RecordNotFoundException("添加收藏异常：商品不存在或已下架");
        }

        // 基于user_id和product_id查询收藏记录
        Favorite favorite = mapper.getByUidAndPid(userId, productId);
        // 判断查询结果是否为null
        if (favorite == null) {
            // 创建收藏记录
            favorite = new Favorite(null, userId, productId,
                                    username, null,
                                    username, null);
            // 调用持久层方法
            Integer row = mapper.insertFavorite(favorite);
            if (row!=1) {
                throw new InsertException("添加收藏异常：新记录添加失败");
            }
        }else{
            // 更新收藏记录
            Integer row = mapper.updateFavorite(favorite.getId(), username);
            if (row!=1) {
                throw new UpdateException("添加收藏异常：记录更新失败");
            }
        }
    }

    @Override
    public void deleteFavoriteByUidAndPid(Integer uid, Integer pid)
            throws RecordNotFoundException, DeleteException {
        // 验证user_id对应的用户数据是否存在
        User user=userService.findById(uid);
        if(user==null || user.getIsDelete()==1){
            throw new RecordNotFoundException("删除收藏异常：用户信息不存在");
        }
        // 基于商品id查询商品数据
        // 判断结果是否为null
        // 是：RecordNotFoundException
        // 判断商品的status是否不为1
        // 是：RecordNotFoundException -> 已下架
        Product product=productService.findByIdInner(pid);
        if(product==null || product.getStatus()!=1){
            throw new RecordNotFoundException("删除收藏异常：商品不存在或已下架");
        }

        // 基于user_id和product_id查询收藏记录
        Favorite favorite = mapper.getByUidAndPid(uid, pid);
        // 判断查询结果是否为null
        if (favorite == null) {
            throw new RecordNotFoundException("删除收藏异常：收藏记录不存在");
        }
        // 调用持久层方法，删除收藏记录
        Integer row = mapper.deleteFavoriteByUidAndPid(uid, pid);
        if (row != 1) {
            throw new DeleteException("删除收藏异常：删除记录失败");
        }
    }

    @Override
    public Favorite getFavoriteByUidAndPid(Integer uid, Integer pid)
            throws RecordNotFoundException {
        // 验证user_id对应的用户数据是否存在
        User user=userService.findById(uid);
        if(user==null || user.getIsDelete()==1){
            throw new RecordNotFoundException("获取收藏异常：用户信息不存在");
        }
        // 基于商品id查询商品数据
        // 判断结果是否为null
        // 是：RecordNotFoundException
        // 判断商品的status是否不为1
        // 是：RecordNotFoundException -> 已下架
        Product product=productService.findByIdInner(pid);
        if(product==null || product.getStatus()!=1){
            throw new RecordNotFoundException("获取收藏异常：商品不存在或已下架");
        }
        return mapper.getByUidAndPid(uid, pid);
    }
}
