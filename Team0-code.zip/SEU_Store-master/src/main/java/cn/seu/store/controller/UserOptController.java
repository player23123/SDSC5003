package cn.seu.store.controller;

import cn.seu.store.common.Constant;
import cn.seu.store.entity.JsonResult;
import cn.seu.store.entity.Product;
import cn.seu.store.entity.User;
import cn.seu.store.entity.UserOptVO;
import cn.seu.store.service.IUserOptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 处理用户行为统计的控制器类
 */
@RestController
@RequestMapping("/userOpt")
public class UserOptController {
    /**
     * 用户行为信息的业务层接口
     */
    @Autowired
    IUserOptService userOptService;

    /**
     * 基于用户id获取用户行为记录
     * @param session 会话
     * @return {@link UserOptVO} 用户行为信息列表
     */
    @RequestMapping("/getHistoryByUid")
    public JsonResult<List<UserOptVO>> getHistoryByUid(HttpSession session) {
        User user = (User)session.getAttribute(Constant.SESSION_USER);
        List<UserOptVO> userOpts = userOptService.getUserOptsByUid(user.getId());
        return JsonResult.getSuccessJR(userOpts);
    }

    /**
     * 获取商城中浏览量最高的商品
     * @return {@link Product}
     */
    @RequestMapping("/getMostPvProduct")
    public JsonResult<Product> getMostPvProduct() {
        Product product = userOptService.getMostOptProduct("pv");
        return JsonResult.getSuccessJR(product);
    }

    /**
     * 获取商城中收藏量最高的商品
     * @return {@link Product}
     */
    @RequestMapping("/getMostFavProduct")
    public JsonResult<Product> getMostFavProduct() {
        Product product = userOptService.getMostOptProduct("fav");
        return JsonResult.getSuccessJR(product);
    }

    /**
     * 获取商城中添加购物车量最高的商品
     * @return {@link Product}
     */
    @RequestMapping("/getMostCartProduct")
    public JsonResult<Product> getMostCartProduct() {
        Product product = userOptService.getMostOptProduct("cart");
        return JsonResult.getSuccessJR(product);
    }

    /**
     * 获取商城中购买量最高的商品
     * @return {@link Product}
     */
    @RequestMapping("/getMostBuyProduct")
    public JsonResult<Product> getMostBuyProduct() {
        Product product = userOptService.getMostOptProduct("buy");
        return JsonResult.getSuccessJR(product);
    }
}
