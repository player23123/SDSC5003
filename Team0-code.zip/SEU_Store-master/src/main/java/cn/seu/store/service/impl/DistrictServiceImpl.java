package cn.seu.store.service.impl;

import cn.seu.store.service.IDistrictService;
import cn.seu.store.service.ex.EmptyArgumentException;
import cn.seu.store.entity.District;
import cn.seu.store.mapper.DistrictMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class DistrictServiceImpl implements IDistrictService {

    @Autowired(required = false)
    DistrictMapper mapper;

    @Override
    public String findNameByCode(String code) throws EmptyArgumentException {
        if(StringUtils.isEmpty(code)){
            throw new EmptyArgumentException("查询区域名称异常：编码为空");
        }
        return mapper.getNameByCode(code);
    }

    @Override
    public List<District> findByParent(String parent) {
        // 非空验证 TODO
        // 验证结果集是否有数据 TODO
        return mapper.listByParent(parent);
    }

}
