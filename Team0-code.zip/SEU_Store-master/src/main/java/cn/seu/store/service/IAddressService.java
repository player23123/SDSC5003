package cn.seu.store.service;

import cn.seu.store.entity.Address;
import cn.seu.store.service.ex.*;

import java.util.List;

/**
 * 收货地址模块的业务层接口
 */
public interface IAddressService {

    /**
     * 基于id查询收货地址
     * @param aid
     * @return
     */
    Address findByAid(Integer aid)
            throws RecordNotFoundException;

    /**
     * 基于地址id删除地址记录
     * 如果删除的是默认默认收货地址，如果：
     * 1. 当前用户还有其他收货地址，则设置最后更新的地址为默认收货地址
     * 2. 当前用户没有其他收货地址，则不进行其他操作
     *
     * @param id
     * @param userId
     * @param username
     * @throws AddressNotFoundException
     * @throws AccessDeniedException
     * @throws DeleteException
     * @throws UpdateException
     */
    void removeAddress(Integer id,Integer userId, String username)
            throws AddressNotFoundException, AccessDeniedException,DeleteException, UpdateException;

    /**
     * 基于aid将用户的收货地址设为默认收货地址
     * @param id
     * @param userId
     * @param username
     * @throws AddressNotFoundException
     * @throws AccessDeniedException
     * @throws UpdateException
     */
    void setDefault(Integer id,Integer userId,String username)
            throws AddressNotFoundException, AccessDeniedException, UpdateException;

    /**
     * 基于用户id查询全部收货地址
     * @param uid
     * @return
     */
    List<Address> findByUid(Integer uid);

    /**
     * 添加收货地址
     * @param userId
     * @param username
     * @param address
     * @throws AddressCountLimitException
     * @throws InsertException
     */
    void createAddress(Integer userId,String username, Address address)
            throws AddressCountLimitException, InsertException;

    /**
     * 更新收货地址
     * @param userId
     * @param username
     * @param address
     * @throws UpdateException
     */
    void updateAddress(Integer userId,String username, Address curAddress, Address address)
            throws UpdateException;
}
