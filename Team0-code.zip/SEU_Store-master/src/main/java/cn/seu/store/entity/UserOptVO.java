package cn.seu.store.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class UserOptVO implements Serializable {
    private Integer productId;
    private String productTitle;
    private Integer categoryId;
    private String categoryName;
    private String type;
    private String createdTime;
}
