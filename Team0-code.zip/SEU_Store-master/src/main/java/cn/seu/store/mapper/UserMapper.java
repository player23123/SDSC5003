package cn.seu.store.mapper;

import cn.seu.store.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;

/**
 * 用户模块的持久层接口
 */
@Mapper
public interface UserMapper {

    /**
     * 更新用户头像信息
     * @param id
     * @param avatar
     * @param modifiedUser
     * @param modifiedTime
     * @return
     */
    Integer updateAvatar(
            @Param("id") Integer id,
            @Param("avatar") String avatar,
            @Param("modifiedUser") String modifiedUser,
            @Param("modifiedTime") Date modifiedTime);

    /**
     * 基于用户id查询用户信息
     * @param id
     * @return
     */
    User getById(Integer id);

    /**
     * 更新用户信息
     * @param user
     * @return
     */
    Integer updateInfo(User user);

    /**
     * 基于用户id更新用户密码
     * @param id
     * @param password
     * @param modifiedUser
     * @param modifiedTime
     * @return
     */
    Integer updatePassword(@Param("id") Integer id,
                           @Param("password")String password,
                           @Param("modifiedUser")String modifiedUser,
                           @Param("modifiedTime") Date modifiedTime);


    /**
     * 添加一条用户记录
     * @param user
     * @return 添加成功的数据行数
     */
    Integer insertUser(User user);

    /**
     * 基于用户名查询用户记录
     * @param username
     * @return
     */
    User getByUsername(String username);

}