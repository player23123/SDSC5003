package cn.seu.store.controller;

import cn.seu.store.service.IDistrictService;
import cn.seu.store.entity.District;
import cn.seu.store.entity.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 处理收货地址中有关区域的相关请求的控制器类
 */
@RestController
@RequestMapping("/districts")
public class DistrictController {
    /**
     * 地区模块的业务层接口
     */
    @Autowired
    IDistrictService service;

    /**
     * 根据父结点的地区信息获取其所有子地区
     * @param parent 父结点地区名称
     * @return {@link District} 子地区列表
     */
    @RequestMapping("/")
    public JsonResult<List<District>> findDistrict(String parent){
        List<District> list=service.findByParent(parent);
        return JsonResult.getSuccessJR(list);
    }
}
