package cn.seu.store.controller;

import com.alipay.api.AlipayApiException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 提供给公网或外部服务器调用的通知类控制器类
 */
@Deprecated
@Controller
@RequestMapping("/notification")
public class NotificationController {
    /**
     * 处理支付宝异步回调通知
     * @param request Http请求
     * @return 回应支付宝的消息字符串
     * @throws AlipayApiException
     */
    @Deprecated
    @PostMapping("/alipayNotify")
    public String alipayNotify(HttpServletRequest request) throws AlipayApiException {
        Map<String,String> params = new HashMap<>();
        Map<String,String[]> requestParams = request.getParameterMap();
        // 将 Map<String,String[]> 转为 Map<String,String>
        for (Iterator<String> iter = requestParams.keySet().iterator(); iter.hasNext();) {
            String name = iter.next();
            String[] values = requestParams.get(name);
            String valueStr = "";
            for (int i = 0; i < values.length; i++) {
                valueStr = (i == values.length - 1) ? valueStr + values[i]
                        : valueStr + values[i] + ",";
            }
            params.put(name, valueStr);
            System.out.println("name: " + name + " value: " + valueStr);
        }
        return "success";
    }
}
