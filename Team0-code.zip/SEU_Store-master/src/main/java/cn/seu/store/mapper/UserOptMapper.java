package cn.seu.store.mapper;

import cn.seu.store.entity.UserOpt;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserOptMapper {

    /**
     * 基于用户id查询
     * 近7天访问最多的商品种类id
     * @param uid
     * @return
     */
    Integer getCidByUid(Integer uid);

    /**
     * 添加一条用户操作记录
     * @param opt
     * @return
     */
    int insertOpt(UserOpt opt);

    /**
     * 一次性插入多条用户操作记录
     * @param opts
     * @return
     */
    int insertOpts(@Param("opts") List<UserOpt> opts);

    /**
     * 基于用户id查询最近的行为记录
     * @param uid
     * @return
     */
    List<UserOpt> getUserOptsByUid(@Param("uid") Integer uid);

    /**
     * 获取用户行为量最多的商品id
     * @param type 'pv' or 'fav' or 'cart' or 'buy'
     * @return 商品id
     */
    Integer getMostOptProductId(@Param("type") String type);
}
