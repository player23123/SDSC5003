package cn.seu.store.service;

import cn.seu.store.entity.Favorite;
import cn.seu.store.entity.FavoriteVO;
import cn.seu.store.service.ex.*;

import java.util.List;

/**
 * 收藏模块的业务层接口
 */
public interface IFavoriteService {
    /**
     * 基于用户id查询所有收藏记录
     * @param uid
     * @return
     * @throws RecordNotFoundException
     */
    List<FavoriteVO> getFavoriteList(Integer uid) throws RecordNotFoundException;

    /**
     * 添加一条收藏记录
     * @param productId 商品id
     * @param userId 用户id
     * @param username 用户名
     * @throws RecordNotFoundException
     * @throws UpdateException
     * @throws InsertException
     */
    public void createFavorite(Integer productId, Integer userId, String username)
            throws RecordNotFoundException, UpdateException, InsertException;


    /**
     * 基于用户id和商品id删除一条收藏记录
     * @param uid 用户id
     * @param pid 商品id
     * @throws RecordNotFoundException
     * @throws DeleteException
     */
    public void deleteFavoriteByUidAndPid(Integer uid, Integer pid)
            throws RecordNotFoundException, DeleteException;

    /**
     * 基于用户id和商品id查找一条收藏记录
     * @param uid
     * @param pid
     * @return
     * @throws RecordNotFoundException
     */
    public Favorite getFavoriteByUidAndPid(Integer uid, Integer pid)
            throws RecordNotFoundException;
}
