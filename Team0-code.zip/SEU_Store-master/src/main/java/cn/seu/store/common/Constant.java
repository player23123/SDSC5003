package cn.seu.store.common;

import cn.seu.store.entity.JsonResult;
import cn.seu.store.entity.User;
import cn.seu.store.service.IOrderService;

public class Constant {
    public static final int MD5_HASH_TIMES=5; // 密码hash迭代次数

    public static final int USER_GENDER_FEMALE=0; // 用户性别编号-女性
    public static final int USER_GENDER_MALE=1; // 用户性别编号-男性
    public static final int USER_GENDER_UNKNOWN=2; // 用户性别编号-未知

    public static final int IS_NOT_DELETE=0; // 标记数据未删除
    public static final int IS_DELETE=1; // 标记数据已删除

    public static final String SESSION_USER="user"; // Session中保存用户信息的key
    public static final JsonResult<User> JR_NOT_LOGGEDIN=new JsonResult<>(2004,"not logged in",null); // 代表用户未登录的JR对象
    public static final JsonResult<Void> JR_SESSION_TIMEOUT=new JsonResult<>(2005,"登录状态已超时"); // 代表用户登录状态已超时的JR对象
    public static final JsonResult<User> JR_SESSION_TIMEOUT_U=new JsonResult<>(2005,"登录状态已超时"); // 代表用户登录状态已超时的JR对象

    public static final int MAX_ADDRESS=3; // 每个用户的最大收货地址条数
    public static final int IS_NOT_DEFAULT=0; // 不是默认收货地址
    public static final int IS_DEFAULT=1; // 是默认收货地址
    public static final Integer MAX_PAGE_SIZE=20; // 商品列表页面中每页最大记录数量

    public static final String OPT_TYPE_PV="pv"; // 用户操作行为-浏览商品
    public static final String OPT_TYPE_FAV="fav"; // 用户操作行为-添加收藏
    public static final String OPT_TYPE_CART="cart"; // 用户操作行为-添加购物车
    public static final String OPT_TYPE_BUY="buy"; // 用户操作行为-购买商品

    public static final Integer ORDER_STATUS_UNPAID=0; // 订单状态-未支付
    public static final Integer ORDER_STATUS_PAID=1; // 订单状态-已支付
    public static final Integer ORDER_STATUS_CANCEL=2; // 订单状态-已取消
    public static final Integer ORDER_STATUS_TIMEOUT=3; // 订单状态-已超时
    public static final Integer ORDER_STATUS_CONFIRMED=4; // 订单状态-已收货

    public final static Integer ORDER_TIMEOUT_MINUTES = 10; // 订单限时支付时间
    public final static Integer PAYMENT_TIMEOUT_MINUTES = 10;

    public final static Integer PRODUCT_STATUS_ONSALE = 1; // 商品状态-上架
    public final static Integer PRODUCT_STATUS_OFFSALE = 2; // 商品状态-下架
    public final static Integer PRODUCT_STATUS_DELETED = 3; // 商品状态-删除
}
