package cn.seu.store.controller;

import cn.seu.store.controller.ex.*;
import cn.seu.store.service.IUserService;
import cn.seu.store.common.Constant;
import cn.seu.store.entity.JsonResult;
import cn.seu.store.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 处理用户相关请求的控制器类
 */
@RestController
@RequestMapping("/users")
public class UserController {
    /**
     * 用户模块的业务层接口
     */
    @Autowired
    IUserService service;

    /**
     * 用户头像的最大分辨率
     */
    private static final long AVATAR_MAX_SIZE=600*1024;

    /**
     * 用户头像支持的文件后缀名
     */
    private static final List<String> AVATAR_TYPES=new ArrayList<String>();

    // 静态初始化器：用于初始化本类的静态成员
    static {
        AVATAR_TYPES.add("image/jpeg");
        AVATAR_TYPES.add("image/jpg");
        AVATAR_TYPES.add("image/png");
    }

    /**
     * 文件路径（读取配置文件中文件上传路径）
     */
    @Value("${uploadPath}")
    private String uploadDir;

    /**
     * 基于用户id，修改用户的头像
     * @param file 头像图片文件
     * @param request Http请求
     * @param session 会话
     * @return {@link String} 图片文件在服务器的文件名
     */
    @PostMapping("/changeAvatar")
    public JsonResult<String> changeAvatar(@RequestParam("file") MultipartFile file,
                                           HttpServletRequest request,HttpSession session){
        System.out.println("[/users/changeAvatar] Start...");
        // 空文件验证
        if(file.isEmpty()) {
            throw new FileEmptyException("文件上传异常！文件不能为空");
        }
        System.out.println("[/users/changeAvatar] File size: " + file.getSize());
        // 文件大小验证
        long fileSize=file.getSize();
        if(fileSize>AVATAR_MAX_SIZE) {
            throw new FileSizeException("文件上传异常！文件大小超过上限:"+(AVATAR_MAX_SIZE/1024)+"kb");
        }
        // 文件类型验证
        System.out.println("[/users/changeAvatar] File type: " + file.getContentType());
        if(!AVATAR_TYPES.contains(file.getContentType())) {
            throw new FileTypeException("文件上传异常！文件类型不正确，允许的类型有："+AVATAR_TYPES);
        }
        // 生成文件名-> 直接使用uuid+原文件名后缀
        String oFilename=file.getOriginalFilename();

        Integer index=oFilename.lastIndexOf(".");
        String suffix="";
        if(index!=-1) {
            suffix=oFilename.substring(index);
        }
        String filename= UUID.randomUUID().toString()+suffix;
        // 直接使用配置好的路径
        File dest=new File(uploadDir,filename);
        System.out.println("[/users/changeAvatar] Upload Path: " + dest.getAbsolutePath());
        if (!dest.getParentFile().exists()) {
            dest.getParentFile().mkdirs();
        }
        // 将用户上传的头像保存到服务器上
        try {
            file.transferTo(dest.getAbsoluteFile());
        } catch (IllegalStateException e) {
            throw new FileStateException("文件上传异常！"+e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            throw new FileIOException("文件上传异常！"+e.getMessage());
        }
        // 将头像名称保存到数据库
        String avatar=filename;
        User user=(User) session.getAttribute("user");
        Integer uid=user.getId();
        String username=user.getUsername();
        service.changeAvatar(uid,avatar,username);
        return JsonResult.getSuccessJR(avatar);
    }

    /**
     * 基于用户id，获取该用户的详细信息
     * @param session 会话
     * @return {@link User} 用户信息
     */
    @RequestMapping("/findDetailUserInfo")
    public JsonResult<User> findDetailUserInfo(HttpSession session){
        User sessionUser=(User)session.getAttribute(Constant.SESSION_USER);
        if (sessionUser==null || sessionUser.getId()==null){
            return Constant.JR_SESSION_TIMEOUT_U;
        }
        User user=service.findById(sessionUser.getId());
        // 补充用户的用户名
        user.setUsername(sessionUser.getUsername());
        return JsonResult.getSuccessJR(user);
    }

    /**
     * 基于用户id，修改该用户的信息
     * @param user 新的用户信息
     * @param session 会话
     * @return Void
     */
    @RequestMapping("/changeInfo")
    public JsonResult<Void> changeInfo(User user,HttpSession session){
        User sessionUser=(User)session.getAttribute(Constant.SESSION_USER);
        if (sessionUser==null || sessionUser.getId()==null){
            return Constant.JR_SESSION_TIMEOUT;
        }
        // 调用service方法更新用户数据
        service.changeInfo(sessionUser.getId(), sessionUser.getUsername(), user);
        return JsonResult.getSuccessJR();
    }

    /**
     * 基于用户id，修改该用户的密码
     * @param oldPassword 旧密码
     * @param newPassword 新密码
     * @param session 会话
     * @return Void
     */
    @RequestMapping("/changePassword")
    public JsonResult<Void> changePassword(String oldPassword,String newPassword,HttpSession session){
        // 查询登录用户信息
        User user=(User)session.getAttribute(Constant.SESSION_USER);
        // 用户登录状态超时
        if (user==null){
            return Constant.JR_SESSION_TIMEOUT;
        }
        // 更新用户密码
        service.changePassword(user.getUsername(),oldPassword,newPassword,user.getUsername());
        // 返回成功提示
        return JsonResult.getSuccessJR();
    }

    /**
     * 登出当前用户（销毁Session对象）
     * @param req Http请求
     * @param resp Http响应
     * @throws IOException
     */
    @RequestMapping("/logout")
    public void logout(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // 获取用户的Session对象并销毁
        req.getSession().invalidate();
        // 配置重定向到首页
        resp.sendRedirect("/web/login.html");
    }

    /**
     * 基于用户id，获取用户信息
     * @param req Http请求
     * @return {@link User} 用户信息
     */
    @RequestMapping ("/findUserInfo")
    public JsonResult<User> findUserInfo(HttpServletRequest req){
        // 获取用户对应的Session对象，如Session对象不存在，不创建新的Session对象
        HttpSession session=req.getSession(false);
        // 未登录
        if (session==null || session.getAttribute(Constant.SESSION_USER)==null){
            return Constant.JR_NOT_LOGGEDIN;
        }
        // 已登录
        User user=(User) session.getAttribute(Constant.SESSION_USER);
        return JsonResult.getSuccessJR(user);
    }

    /**
     * 处理用户登录（用户密码使用MD5加密，服务器不存储明文）
     * @param username 用户名
     * @param password 密码
     * @param req Http请求
     * @return {@link User} 用户信息
     */
    @RequestMapping("/login")
    public JsonResult<User> login(String username, String password, HttpServletRequest req){
        User user=service.login(username,password);
        HttpSession session=req.getSession();
        // 向Session添加用户的登录状态
        session.setAttribute(Constant.SESSION_USER,user);
        return JsonResult.getSuccessJR(user);
    }

    /**
     * 处理用户注册（用户密码使用MD5加密，服务器不存储明文）
     * @param user 新用户信息
     * @return Void
     */
    @RequestMapping("/regist")
    public JsonResult<Void> regist(User user){
        service.regist(user);
        return new JsonResult<Void>(1000,"OK");
    }
}