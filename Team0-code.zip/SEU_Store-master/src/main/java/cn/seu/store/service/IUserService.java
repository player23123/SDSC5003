package cn.seu.store.service;

import cn.seu.store.entity.User;
import cn.seu.store.service.ex.*;

public interface IUserService {

    /**
     * 修改用户头像信息
     * @param id
     * @param avatar
     * @param modifiedUser
     * @throws RecordNotFoundException
     * @throws UpdateException
     */
    void changeAvatar (Integer id,  String avatar, String modifiedUser)
            throws RecordNotFoundException, UpdateException;

    /**
     * 基于用户ID查询用户信息
     * @param id
     * @return
     */
    User findById(Integer id) throws RecordNotFoundException;

    /**
     * 基于用户ID更新用户信息
     * @param id
     * @param username 修改信息的用户名
     * @param user 新的用户数据
     * @throws UpdateException
     */
    void changeInfo(Integer id, String username, User user)
            throws RecordNotFoundException, UpdateException;

    /**
     * 基于用户名修改用户密码
     * @param username
     * @param oldPassword
     * @param newPassword
     * @param modifiedUser
     * @throws EmptyArgumentException
     * @throws ChangePasswordException
     */
    void changePassword(String username, String oldPassword,
                        String newPassword,String modifiedUser)
            throws EmptyArgumentException, ChangePasswordException, UpdateException;

    /**
     * 用户登录
     * @param username
     * @param password
     * @return 封装了用户信息的对象 或 null
     * @throws EmptyArgumentException
     * @throws LoginException
     */
    User login(String username,String password)
            throws EmptyArgumentException, LoginException;


    /**
     * 用户注册
     * @param user 用户注册信息
     * @throws EmptyArgumentException
     * @throws UserExistException
     * @throws InsertException
     */
    void regist(User user)
            throws EmptyArgumentException, UserExistException, InsertException;

}
