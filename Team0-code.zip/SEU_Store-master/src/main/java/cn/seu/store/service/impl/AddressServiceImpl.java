package cn.seu.store.service.impl;

import cn.seu.store.common.Constant;
import cn.seu.store.entity.Address;
import cn.seu.store.mapper.AddressMapper;
import cn.seu.store.service.IAddressService;
import cn.seu.store.service.IDistrictService;
import cn.seu.store.service.ex.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class AddressServiceImpl implements IAddressService {

    @Autowired(required = false)
    AddressMapper mapper;

    @Autowired
    IDistrictService districtService;

    @Override
    public Address findByAid(Integer aid) throws RecordNotFoundException{
        if(aid==null){
            throw new RecordNotFoundException("查询收货地址异常：id不能为空");
        }
        return mapper.getById(aid);
    }

    @Override
    @Transactional
    public void removeAddress(Integer id,Integer userId, String username)
            throws AddressNotFoundException, AccessDeniedException, DeleteException, UpdateException {
        // 非空验证 TODO
        Address address=null;
        try{
            address=mapper.getById(id);
        }catch (Exception e){
            e.printStackTrace();
            throw new UpdateException("删除收货地址异常："+e.getMessage(),e);
        }
        // 验证aid对应的记录是否不存在
        if(address==null){
            // 是：AddressNotFoundException
            throw new AddressNotFoundException("删除收货地址异常：地址不存在");
        }

        // 验证当前用户是否没有该记录操作权限
        if(!userId.equals(address.getUserId())){
            // 是：AccessDeniedException
            throw new AccessDeniedException("删除收货地址异常：权限不足");
        }

        // 删除aid对应的收货地址
        int row1=0;
        try{
            row1=mapper.deleteById(id);
        }catch (Exception e){
            e.printStackTrace();
            throw new DeleteException("删除收货地址异常："+e.getMessage(),e);
        }
        // 判断返回值结果是否不为1
        if(row1!=1){
            // 是：DeleteException
            throw new DeleteException("删除收货地址异常：地址删除失败");
        }

        // 判断查询结果中isDefault是否为1
        if(address.getIsDefault().equals(1)){
            // 是：查找最后更新的收货地址
            Address lastModified=null;
            try{
                lastModified=mapper.getLastModified(userId);
            }catch (Exception e){
                e.printStackTrace();
                throw new UpdateException("删除收货地址异常："+e.getMessage(),e);
            }
            // 判断查询结果是否不为null
            if(lastModified!=null){
                // 是：将该地址设为默认收货地址
                int row2=0;
                try{
                    row2=mapper.updateDefault(lastModified.getId(),username,new Date());
                }catch (Exception e){
                    e.printStackTrace();
                    throw new UpdateException("删除收货地址异常："+e.getMessage(),e);
                }
                // 判断返回值是否不为1
                if(row2!=1){
                    // 是：UpdateException
                    throw new UpdateException("删除收货地址异常：设置默认收货地址失败");
                }
            }
        }
    }

    @Override
    @Transactional
    public void setDefault(Integer id,Integer userId,String username)
            throws AddressNotFoundException, AccessDeniedException, UpdateException {
        // 非空验证 TODO
        Address address=null;
        try{
            address=mapper.getById(id);
        }catch (Exception e){
            e.printStackTrace();
            throw new UpdateException("设置默认收货地址异常："+e.getMessage(),e);
        }
        // 验证aid对应的记录是否不存在
        if(address==null){
            // 是：AddressNotFoundException
            throw new AddressNotFoundException("设置默认收货地址异常：地址不存在");
        }

        // 验证当前用户是否没有该记录操作权限
        if(!userId.equals(address.getUserId())){
            // 是：AccessDeniedException
            throw new AccessDeniedException("设置默认收货地址异常：权限不足");
        }

        // 将该用户所有收货地址设为非默认
        try{
            mapper.updateNonDefault(userId);
        }catch (Exception e){
            e.printStackTrace();
            throw new UpdateException("设置默认收货地址异常："+e.getMessage(),e);
        }
        // 将指定收货地址设为默认收货地址
        int row=0;
        try{
            row=mapper.updateDefault(id,username,new Date());
        }catch (Exception e){
            e.printStackTrace();
            throw new UpdateException("设置默认收货地址异常："+e.getMessage(),e);
        }
        // 判断返回值是否不为1
        if(row!=1){
            // 是：UpdateException
            throw new UpdateException("设置默认收货地址异常：设置失败");
        }
    }

    @Override
    public List<Address> findByUid(Integer userId) {
        List<Address> list=mapper.listByUserId(userId);
        for(Address address:list){
            address.setCreatedUser(null);
            address.setCreatedTime(null);
            address.setModifiedUser(null);
            address.setModifiedTime(null);
        }
        return list;
    }

    @Override
    public void createAddress(Integer userId, String username, Address address)
            throws AddressCountLimitException, InsertException {
        // 检查地址是否存在
        Address curAddress = mapper.getById(address.getId());
        if (curAddress != null) { // 地址存在，则更新地址
            updateAddress(userId, username, curAddress, address);
            return;
        }

        // 基于用户id，查询用户地址数量
        int count=0;
        try{
            count=mapper.countByUserId(userId);
        }catch (Exception e){
            e.printStackTrace();
            throw new InsertException("添加地址异常："+e.getMessage(),e);
        }
        // 判断地址数量是否达到上限
        if(count>= Constant.MAX_ADDRESS){
            // 是：AddressCountLimitException
            throw new AddressCountLimitException("添加地址异常：地址数量已达上限");
        }

        // 判断地址数量是否为0
        if(count==0){
            // 是：设置address中的isDefault为1
            address.setIsDefault(Constant.IS_DEFAULT);
        }else{
            address.setIsDefault(Constant.IS_NOT_DEFAULT);
        }

        // 补全userId
        address.setUserId(userId);

        // 补全省市区数据：补充省市区名称
        String provinceName=districtService.findNameByCode(address.getProvinceCode().toString());
        String cityName=districtService.findNameByCode(address.getCityCode().toString());
        String areaName=districtService.findNameByCode(address.getAreaCode().toString());
        address.setProvinceName(provinceName);
        address.setCityName(cityName);
        address.setAreaName(areaName);

        // 添加日志信息
        address.setCreatedUser(username);
        address.setModifiedUser(username);
        // 执行添加地址操作
        int row=0;
        try{
            row=mapper.saveAddress(address);
        }catch (Exception e){
            e.printStackTrace();
            throw new InsertException("添加地址异常："+e.getMessage(),e);
        }
        // 判断返回值是否不为1
        if(row!=1){
            // 是：InsertException
            throw new InsertException("添加地址异常：地址添加失败");
        }
    }

    @Override
    public void updateAddress(Integer userId, String username, Address curAddress, Address address) throws UpdateException {
        address.setUserId(userId);
        String provinceName=districtService.findNameByCode(address.getProvinceCode().toString());
        String cityName=districtService.findNameByCode(address.getCityCode().toString());
        String areaName=districtService.findNameByCode(address.getAreaCode().toString());
        address.setProvinceName(provinceName);
        address.setCityName(cityName);
        address.setAreaName(areaName);
        address.setModifiedUser(username);

        address.setCreatedUser(curAddress.getCreatedUser());
        address.setCreatedTime(curAddress.getCreatedTime());
        address.setIsDefault(curAddress.getIsDefault());

        int row = mapper.updateAddress(address);
        if (row != 1) {
            throw new UpdateException("更新地址异常：更新地址失败");
        }
    }
}
