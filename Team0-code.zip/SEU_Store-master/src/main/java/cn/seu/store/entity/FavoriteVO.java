package cn.seu.store.entity;

import java.io.Serializable;
import java.util.Objects;

/**
 * 封装收藏列表种一条记录的实体类
 */
public class FavoriteVO implements Serializable {
    private Integer fid;
    private Integer uid;
    private Integer pid;
    private String image;
    private String title;
    private Long price;

    private Integer cid;

    public FavoriteVO() {

    }

    public FavoriteVO(Integer fid, Integer uid, Integer pid, String image, String title, Long price, Integer cid) {
        this.fid = fid;
        this.uid = uid;
        this.pid = pid;
        this.image = image;
        this.title = title;
        this.price = price;
        this.cid = cid;
    }

    public Integer getFid() { return fid; }

    public void setFid(Integer fid) { this.fid = fid; }

    public Integer getUid() { return uid; }

    public void setUid(Integer uid) { this.uid = uid; }

    public Integer getPid() { return pid; }

    public void setPid(Integer pid) { this.pid = pid; }

    public String getImage() { return image; }

    public void setImage(String image) { this.image = image; }

    public String getTitle() { return title; }

    public void setTitle(String title)  { this.title = title; }

    public Long getPrice() { return price; }

    public void setPrice(Long price) { this.price = price; }

    public Integer getCid() { return cid; }

    public void setCid(Integer cid) { this.cid = cid; }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        FavoriteVO favoriteVO = (FavoriteVO) o;
        return Objects.equals(fid, favoriteVO.getFid())
                && Objects.equals(uid, favoriteVO.getUid())
                && Objects.equals(pid, favoriteVO.getPid())
                && Objects.equals(image, favoriteVO.getImage())
                && Objects.equals(title, favoriteVO.getTitle())
                && Objects.equals(price, favoriteVO.getPrice())
                && Objects.equals(cid, favoriteVO.getCid());
    }

    @Override
    public int hashCode() { return Objects.hash(fid, uid, pid, image, title, price, cid); }

    @Override
    public String toString() {
        return "FavoriteVO{" +
                "fid=" + fid +
                ", uid=" + uid +
                ", pid=" + pid +
                ", image='" + image + '\'' +
                ", title='" + title + '\'' +
                ", price=" + price +
                ", inCart" + cid +
                '}';
    }
}
