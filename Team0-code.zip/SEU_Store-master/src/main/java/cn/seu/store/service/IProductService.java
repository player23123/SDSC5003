package cn.seu.store.service;

import cn.seu.store.entity.PageRecord;
import cn.seu.store.entity.Product;
import cn.seu.store.entity.ProductCategory;
import cn.seu.store.service.ex.EmptyArgumentException;
import cn.seu.store.service.ex.ProductOutOfStockException;
import cn.seu.store.service.ex.RecordNotFoundException;
import cn.seu.store.service.ex.UpdateException;

import java.util.List;

/**
 * 商品模块的业务层接口
 */
public interface IProductService {

    /**
     * 基于商品名称模糊、分页查询商品记录
     * @param name 商品名称
     * @param currentPage 当前页页码
     * @param pageSize 每页数据条数
     * @throws RecordNotFoundException
     * @return
     */
    PageRecord<List<Product>> findProductByName(
            String name, Integer currentPage, Integer pageSize)
                throws RecordNotFoundException;

    /**
     * 基于商品id增加商品库存
     * @param pid 商品id
     * @param num 要增加的库存数量
     * @throws RecordNotFoundException
     * @throws UpdateException
     */
    void increaseProductNum(Integer pid, Integer num)
            throws RecordNotFoundException, UpdateException;
    void increaseProductNum(Integer pid,Integer num, Boolean updatePriority)
            throws RecordNotFoundException, UpdateException;


    /**
     * 基于商品id减少商品库存
     * @param pid 商品id
     * @param num 要减少的库存数量
     */
    void reduceProductNum(Integer pid,Integer num)
            throws RecordNotFoundException, ProductOutOfStockException, UpdateException;
    void reduceProductNum(Integer pid,Integer num, Boolean updatePriority)
            throws RecordNotFoundException, ProductOutOfStockException, UpdateException;

    /**
     * 基于uid为用户推荐4件商品
     * 如果用户id为null 或者
     * 用户近期没有访问记录
     * 则使用默认商品种类进行查询
     * @param uid
     * @return
     */
    List<Product> findFavourite(Integer uid);

    /**
     * 基于商品种类id分页查询商品记录
     * @param cid 商品种类id
     * @param currentPage 当前页页码
     * @param pageSize 每页数据条数
     * @throws RecordNotFoundException
     * @return
     */
    PageRecord<List<Product>> findProductByCid(
            Integer cid, Integer currentPage, Integer pageSize)
            throws RecordNotFoundException;

    /**
     * 查询所有商品种类信息
     * @return
     */
    List<ProductCategory> findAllCategory();

    /**
     * 供其他业务层方法调用的查询方法
     * 功能与findById相同
     * 不会产生用户操作记录
     * @param id
     * @return
     */
    Product findByIdInner(Integer id)
            throws EmptyArgumentException, RecordNotFoundException;

    /**
     * 基于商品id查询商品数据
     * @param id
     * @return
     */
    Product findById(Integer id)
            throws EmptyArgumentException, RecordNotFoundException;

    /**
     * 查询热销排行商品
     * @return
     */
    List<Product> findHotList();

}
