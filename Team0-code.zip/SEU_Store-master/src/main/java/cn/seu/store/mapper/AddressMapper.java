package cn.seu.store.mapper;

import cn.seu.store.entity.Address;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

@Mapper
public interface AddressMapper {

    /**
     * 基于用户id查询用户最后更新的一条收货地址记录
     * @param userId
     * @return
     */
    Address getLastModified(Integer userId);

    /**
     * 基于地址id删除一条地址记录
     * @param id
     * @return
     */
    Integer deleteById(Integer id);

    /**
     * 基于地址id将地址设为默认收货地址
     * @param id
     * @param username
     * @param modifiedTime
     * @return
     */
    Integer updateDefault(
            @Param("id") Integer id,
            @Param("username") String username,
            @Param("modifiedTime") Date modifiedTime);

    /**
     * 将该用户所有收货地址设为默认收货地址
     * @param userId
     * @return
     */
    Integer updateNonDefault(Integer userId);

    /**
     * 基于id查询收货地址记录
     * @param id
     * @return
     */
    Address getById(Integer id);

    /**
     * 基于用户id查询收货地址列表
     * @param userId
     * @return
     */
    List<Address> listByUserId(Integer userId);

    /**
     * 新增收货地址
     * @param address
     * @return
     */
    Integer saveAddress(Address address);

    /**
     * 更新收货地址
     * @param address
     * @return
     */
    Integer updateAddress(Address address);

    /**
     * 查询用户收货地址条数
     * @param userId
     * @return
     */
    Integer countByUserId(Integer userId);

}
