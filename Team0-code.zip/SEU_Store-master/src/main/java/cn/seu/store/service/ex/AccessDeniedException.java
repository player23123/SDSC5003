package cn.seu.store.service.ex;

/**
 * 当前用户没有该记录访问权限时抛出的异常
 */
public class AccessDeniedException extends ServiceException{
    public AccessDeniedException() {
    }
    public AccessDeniedException(String message) {
        super(message);
    }
    public AccessDeniedException(String message, Throwable cause) {
        super(message, cause);
    }
    public AccessDeniedException(Throwable cause) {
        super(cause);
    }
    public AccessDeniedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
