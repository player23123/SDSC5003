package cn.seu.store.entity;

import cn.seu.store.common.Constant;
import cn.seu.store.service.IOrderService;
import cn.seu.store.service.IPaymentService;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class AliPayOrder {
    public static final String WAIT_BUYER_PAY = "WAIT_BUYER_PAY";
    public static final String TRADE_CLOSED = "TRADE_CLOSED";
    public static final String TRADE_SUCCESS = "TRADE_SUCCESS";
    public static final String TRADE_FINISHED = "TRADE_FINISHED";

    private String out_trade_no;
    private String product_code = "FAST_INSTANT_TRADE_PAY";
    private Long total_amount;
    private String subject;
    private String body;
    private String timeout_express = Constant.PAYMENT_TIMEOUT_MINUTES.toString() + "m";

    public static AliPayOrder generateFromOrder(Order order) {
        AliPayOrder aliPayOrder = new AliPayOrder();
        aliPayOrder.setOut_trade_no(order.getId().toString());
        aliPayOrder.setTotal_amount(order.getTotalPrice());
        aliPayOrder.setSubject(
                order.getId().toString() + "-" +
                order.getUserId().toString() + "-" +
                order.getOrderTime().toString()
        );
        List<OrderItem> orderItems = order.getOrderItems();
        String firstItemTitle = orderItems.get(0).getTitle();
        String orderBody = firstItemTitle.length() > 128 ? firstItemTitle.substring(0, 128) : firstItemTitle;
        int itemsLen = orderItems.size();
        for (int i = 1; i < itemsLen; ++i) {
            String itemTitle = orderItems.get(i).getTitle();
            if (orderBody.length() + itemTitle.length() > 128) {
                break;
            }
            orderBody += "-" + itemTitle;
        }
        aliPayOrder.setBody(orderBody);
        return aliPayOrder;
    }
}
