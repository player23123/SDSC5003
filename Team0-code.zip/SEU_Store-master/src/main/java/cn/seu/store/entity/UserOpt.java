package cn.seu.store.entity;

import java.util.Date;

public class UserOpt {
    private Integer id;
    private Integer userId;
    private Integer productId;
    private Integer categoryId;
    private String type;
    private Date createdTime;

    public UserOpt() {
    }

    public UserOpt(Integer id, Integer userId, Integer productId, Integer categoryId, String type, Date createdTime) {
        this.id = id;
        this.userId = userId;
        this.productId = productId;
        this.categoryId = categoryId;
        this.type = type;
        this.createdTime = createdTime;
    }

    public UserOpt(Integer userId, Integer productId, Integer categoryId, String type, Date createdTime) {
        this.userId = userId;
        this.productId = productId;
        this.categoryId = categoryId;
        this.type = type;
        this.createdTime = createdTime;
    }

    public Integer getId() { return id; }

    public void setId(Integer id) { this.id = id; }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    @Override
    public String toString() {
        return "UserOpt{" +
                "userId=" + userId +
                ", productId=" + productId +
                ", categoryId=" + categoryId +
                ", type='" + type + '\'' +
                ", createdTime=" + createdTime +
                '}';
    }
}
