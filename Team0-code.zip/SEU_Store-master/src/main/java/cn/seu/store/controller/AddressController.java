package cn.seu.store.controller;

import cn.seu.store.common.Constant;
import cn.seu.store.entity.Address;
import cn.seu.store.entity.JsonResult;
import cn.seu.store.entity.User;
import cn.seu.store.service.IAddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 处理收货地址相关请求的控制器类
 */
@RestController
@RequestMapping("/addresses")
public class AddressController {
    /**
     * 收货地址模块的业务层接口
     */
    @Autowired
    IAddressService service;

    /**
     * 基于地址id和用户id，移除一条收货地址记录
     * @param aid 收货地址id
     * @param session 会话
     * @return Void
     */
    @PostMapping("/{aid}/delete")
    public JsonResult<Void> removeAddress(@PathVariable("aid") Integer aid, HttpSession session){
        User user=(User)session.getAttribute(Constant.SESSION_USER);
        service.removeAddress(aid,user.getId(),user.getUsername());
        return JsonResult.getSuccessJR();
    }

    /**
     * 基于地址id和用户id将一条收货地址记录设为该用户的默认收货地址
     * @param aid 收货地址id
     * @param session 会话
     * @return Void
     */
    @RequestMapping("/{aid}/set_default")
    public JsonResult<Void> setDefault(
            @PathVariable("aid") Integer aid, HttpSession session){
        User user=(User)session.getAttribute(Constant.SESSION_USER);
        service.setDefault(aid,user.getId(),user.getUsername());
        return JsonResult.getSuccessJR();
    }

    /**
     * 基于用户id获取该用户的全部收货地址
     * @param session 会话
     * @return {@link Address} 收货地址列表
     */
    @RequestMapping("/list")
    public JsonResult<List<Address>> findByUserId(HttpSession session){
        User user=(User)session.getAttribute(Constant.SESSION_USER);
        List<Address> list=service.findByUid(user.getId());
        return JsonResult.getSuccessJR(list);
    }

    /**
     * 基于用户id，为该用户创建一条收货地址
     * @param address 收货地址实体类
     * @param session 会话
     * @return Void
     */
    @PostMapping("/createAddress")
    public JsonResult<Void> createAddress(Address address, HttpSession session){
        User user=(User)session.getAttribute(Constant.SESSION_USER);
        service.createAddress(user.getId(),user.getUsername(),address);
        return JsonResult.getSuccessJR();
    }

    /**
     * 基于地址id获取相应的地址信息
     * @param aid 地址id
     * @return {@link Address} 收货地址信息
     */
    @PostMapping("/getAddressById")
    public JsonResult<Address> getAddressById(Integer aid) {
        Address address = service.findByAid(aid);
        return JsonResult.getSuccessJR(address);
    }
}