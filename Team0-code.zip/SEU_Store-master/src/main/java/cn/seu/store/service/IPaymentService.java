package cn.seu.store.service;

import com.alipay.api.AlipayApiException;
import com.alipay.api.response.AlipayTradePagePayResponse;

public interface IPaymentService {
    /**
     * 使用支付宝支付订单
     * @param oid
     * @param username
     * @return
     * @throws AlipayApiException
     */
    public String alipay(Integer oid, String username) throws AlipayApiException;
}
