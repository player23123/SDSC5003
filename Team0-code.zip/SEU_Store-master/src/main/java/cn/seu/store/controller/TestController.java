package cn.seu.store.controller;

import cn.seu.store.entity.JsonResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 控制器层测试接口
 */
@Deprecated
@RestController
@RequestMapping("/tests")
public class TestController {
    /**
     * 测试接口
     * @return {@link String} 消息字符串
     */
    @Deprecated
    @RequestMapping("/helloworld")
    public JsonResult<String> testHelloWorld() {
        return JsonResult.getSuccessJR("Hello World!");
    }
}
