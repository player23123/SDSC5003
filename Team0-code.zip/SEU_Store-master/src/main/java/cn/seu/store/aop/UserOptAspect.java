package cn.seu.store.aop;

import cn.seu.store.service.impl.UserServiceImpl;
import cn.seu.store.common.Constant;
import cn.seu.store.entity.User;
import cn.seu.store.entity.UserOpt;
import cn.seu.store.mapper.CartMapper;
import cn.seu.store.mapper.ProductMapper;
import cn.seu.store.mapper.UserOptMapper;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@Component
@Aspect
public class UserOptAspect {
    @Autowired(required = false)
    ProductMapper productMapper;
    @Autowired(required = false)
    UserOptMapper optMapper;
    @Autowired(required = false)
    CartMapper cartMapper;

    private HashSet<String> targetMethodNames = new HashSet<String>() {{
        add("findById");
        add("createFavorite");
        add("createCart");
        add("createOrder");
    }};

    // pjp是目标方法的句柄
    @Around("execution(* cn.seu.store.service.impl.*.*(..))")
    public Object getOptAdvice(ProceedingJoinPoint pjp)
            throws Throwable {
        // String className=pjp.getTarget().getClass().getName(); // 目标类名
        String methodName=pjp.getSignature().getName(); // 目标方法名
        if (!targetMethodNames.contains(methodName)) {
            return pjp.proceed();
        }
        // 获取目标方法的参数
        Object[] args=pjp.getArgs();

        UserOpt opt=new UserOpt();
        // 填充所需的数据
        // uid
        opt.setUserId(getUid());
        // pid 不同方法获取逻辑不同
        Integer pid=-1;
        switch (methodName){
            case "findById": // 查看商品
                Class cl=pjp.getTarget().getClass();
                if (cl.equals(UserServiceImpl.class)){
                    // 规避统计IUserService下的findById方法
                    break;
                }
                pid=(Integer)args[0];
                opt.setProductId(pid);
                // cid
                opt.setCategoryId(productMapper.getCidByPid(pid));
                // type
                opt.setType(Constant.OPT_TYPE_PV);
                // 写入数据库
                optMapper.insertOpt(opt);
                break;
            case "createFavorite": // 创建收藏
                pid=(Integer)args[0];
                opt.setProductId(pid);
                // cid
                opt.setCategoryId(productMapper.getCidByPid(pid));
                // type
                opt.setType(Constant.OPT_TYPE_FAV);
                // 写入数据库
                optMapper.insertOpt(opt);
                break;
            case "createCart": // 创建购物车
                pid=(Integer)args[0];
                opt.setProductId(pid);
                // cid
                opt.setCategoryId(productMapper.getCidByPid(pid));
                // type
                opt.setType(Constant.OPT_TYPE_CART);
                // 写入数据库
                optMapper.insertOpt(opt);
                break;
            case "createOrder": // 创建订单
                Integer[] cids=(Integer[])args[1];
                // 使用cid查询对应的pid
                List<Integer> pids=cartMapper.listPidByCids(cids);
                // 使用pid查询对应的商品种类id
                List<Integer> cateIds=productMapper.listCidByPids(pids);
                // 便利生成userOpt对象，写入数据库
                // 多行记录插入 1. 拼接成一条语句 2. batch
                List<UserOpt> userOpts=new ArrayList<>();
                Integer uid=getUid();
                for(int i=0;i<pids.size();i++){
                    UserOpt userOpt=new UserOpt();
                    userOpt.setUserId(uid);
                    userOpt.setProductId(pids.get(i));
                    userOpt.setCategoryId(cateIds.get(i));
                    userOpt.setType(Constant.OPT_TYPE_BUY);
                    userOpts.add(userOpt);
                }
                optMapper.insertOpts(userOpts);
                break;
            default:
                break;
        }
        // 调用目标方法
        Object result=pjp.proceed();
        return result;
    }

    public Integer getUid(){
        // 通过Spring提供的RequestContextHolder获取当前用户对应的request对象
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        HttpSession session=request.getSession();
        User user=(User) session.getAttribute(Constant.SESSION_USER);
        if (user==null||user.getId()==null){
            return 0;
        }else {
            return user.getId();
        }
    }

}
