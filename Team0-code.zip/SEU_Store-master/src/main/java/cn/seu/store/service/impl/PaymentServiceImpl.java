package cn.seu.store.service.impl;

import cn.seu.store.common.Constant;
import cn.seu.store.entity.Order;
import cn.seu.store.entity.AliPayOrder;
import cn.seu.store.config.AliPayConfig;
import cn.seu.store.service.IOrderService;
import cn.seu.store.service.IPaymentService;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.request.AlipayTradePagePayRequest;
import com.alipay.api.request.AlipayTradeQueryRequest;
import com.alipay.api.response.AlipayTradePagePayResponse;
import com.alipay.api.response.AlipayTradeQueryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Service
public class PaymentServiceImpl implements IPaymentService {
    @Autowired
    private AliPayConfig aliPayConfig;

    @Autowired
    private IOrderService orderService;

    private final Long checkAliPayTimeInterval = 10000L;
    private final Long maxCheckAliPayWaitingTime = Constant.PAYMENT_TIMEOUT_MINUTES * 60 * 1000L;

    @Override
    public String alipay(Integer oid, String username) throws AlipayApiException {
        // 支付宝支付客户端
        AlipayClient alipayClient = new DefaultAlipayClient(
                aliPayConfig.getGatewayUrl(),
                aliPayConfig.getAppId(),
                aliPayConfig.getPrivateKey(),
                "json",
                aliPayConfig.getCharset(),
                aliPayConfig.getPublicKey(),
                aliPayConfig.getSignType()
        );
        // 请求参数
        AlipayTradePagePayRequest alipayTradePagePayRequest = new AlipayTradePagePayRequest();
        alipayTradePagePayRequest.setReturnUrl(aliPayConfig.getReturnUrl() + "?oid=" + oid.toString() + "&status=1");
        alipayTradePagePayRequest.setNotifyUrl(aliPayConfig.getNotifyUrl());
        Order order = orderService.getByOid(oid);
        AliPayOrder alipayOrder = AliPayOrder.generateFromOrder(order);
        alipayTradePagePayRequest.setBizContent(JSON.toJSONString(alipayOrder));
        // 支付并返回结果
        AlipayTradePagePayResponse alipayResponse = alipayClient.pageExecute(alipayTradePagePayRequest);
        checkAliPayStatus(alipayClient, alipayOrder.getOut_trade_no(), username);
        return alipayResponse.getBody();
    }

    private void checkAliPayStatus(AlipayClient alipayClient, String out_trade_no, String username) {
        Runnable runnable = () -> {
            Long timeElapsed = 0L;
            while (timeElapsed < maxCheckAliPayWaitingTime) {
                System.out.println("Check AliPayOrder: " + out_trade_no);

                AlipayTradeQueryResponse alipayResponse = new AlipayTradeQueryResponse();
                try {
                    alipayResponse = getAliPayResponse(alipayClient, out_trade_no);
                } catch (AlipayApiException e) {
                    e.printStackTrace();
                }
                String tradeStatus = alipayResponse.getTradeStatus() == null ? "NULL" : alipayResponse.getTradeStatus();
                System.out.println("AliPayOrder: " + out_trade_no + ", Status: " + tradeStatus);
                if (tradeStatus.equals(AliPayOrder.TRADE_SUCCESS)) {
                    Integer oid = Integer.parseInt(out_trade_no);
                    Order order = orderService.getByOid(oid);
                    // 订单支付成功
                    orderService.payOrder(Integer.parseInt(out_trade_no), alipayResponse.getSendPayDate(), username);
                    /*if (order.getStatus() == Constant.ORDER_STATUS_UNPAID) {
                        // 订单支付成功
                        orderService.payOrder(Integer.parseInt(out_trade_no), alipayResponse.getSendPayDate(), username);
                    }*/
                    break;
                } else if (tradeStatus.equals(AliPayOrder.TRADE_CLOSED)) {
                    // 订单支付超时
                    orderService.changeStatus(Integer.parseInt(out_trade_no), Constant.ORDER_STATUS_TIMEOUT, username);
                    break;
                }

                // 阻塞
                timeElapsed += checkAliPayTimeInterval;
                try {
                    Thread.sleep(checkAliPayTimeInterval);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };

        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        RequestContextHolder.setRequestAttributes(servletRequestAttributes, true);
        // 开启子线程，查询支付宝订单状态
        Thread thread = new Thread(runnable);
        thread.start();
    }

    private AlipayTradeQueryResponse getAliPayResponse(AlipayClient alipayClient, String out_trade_no) throws AlipayApiException {
        AlipayTradeQueryRequest alipayTradeQueryRequest = new AlipayTradeQueryRequest();
        JSONObject bizContent = new JSONObject();
        bizContent.put("out_trade_no", out_trade_no);
        bizContent.put("trade_no", "");
        alipayTradeQueryRequest.setBizContent(bizContent.toString());
        AlipayTradeQueryResponse alipayResponse = alipayClient.execute(alipayTradeQueryRequest);
        return alipayResponse;
    }

}
