package cn.seu.store.controller;

import cn.seu.store.common.Constant;
import cn.seu.store.entity.Favorite;
import cn.seu.store.entity.FavoriteVO;
import cn.seu.store.entity.User;
import cn.seu.store.entity.JsonResult;
import cn.seu.store.service.IFavoriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 处理收藏相关请求的控制器类
 */
@RestController
@RequestMapping("/favorites")
public class FavoriteController {
    /**
     * 收藏模块的业务层接口
     */
    @Autowired
    IFavoriteService service;

    /**
     * 基于用户id获取用户的收藏列表
     * @param session 会话
     * @return {@link FavoriteVO} 收藏信息列表
     */
    @RequestMapping("/list")
    public JsonResult<List<FavoriteVO>> getFavoriteList(HttpSession session) {
        User user = (User)session.getAttribute(Constant.SESSION_USER);
        List<FavoriteVO> list = service.getFavoriteList(user.getId());
        return JsonResult.getSuccessJR(list);
    }

    /**
     * 基于用户id和商品id，为该用户添加一条收藏记录
     * @param product_id 商品id
     * @param session 会话
     * @return Void
     */
    @RequestMapping("/create")
    public JsonResult<Void> createFavorite(Integer product_id, HttpSession session) {
        User user = (User)session.getAttribute(Constant.SESSION_USER);
        service.createFavorite(product_id, user.getId(), user.getUsername());
        return JsonResult.getSuccessJR();
    }

    /**
     * 基于用户id和商品id，删除一条收藏记录
     * @param pid 商品id
     * @param session 会话
     * @return Void
     */
    @RequestMapping("/delete")
    public JsonResult<Void> deleteFavoriteByUidAndPid(Integer pid, HttpSession session) {
        User user = (User)session.getAttribute(Constant.SESSION_USER);
        service.deleteFavoriteByUidAndPid(user.getId(), pid);
        return JsonResult.getSuccessJR();
    }

    /**
     * 基于用户id和商品id，获取一条用户的收藏记录
     * @param pid 商品id
     * @param session 会话
     * @return {@link Favorite} 收藏信息
     */
    @RequestMapping("/getFavoriteByPid")
    public JsonResult<Favorite> getFavoriteByPid(Integer pid, HttpSession session) {
        User user = (User)session.getAttribute(Constant.SESSION_USER);
        Favorite favorite = service.getFavoriteByUidAndPid(user.getId(), pid);
        return JsonResult.getSuccessJR(favorite);
    }
}
