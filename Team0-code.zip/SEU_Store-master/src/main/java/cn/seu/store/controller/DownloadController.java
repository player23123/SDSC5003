package cn.seu.store.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.io.*;

/**
 * 处理头像文件下载相关请求的控制器类
 */
@RestController
@RequestMapping("/download")
public class DownloadController {
    // 使用Spring的DI功能，动态读取application.properties中的配置
    /**
     * 文件下载路径
     */
    @Value("${uploadPath}")
    private String fileDir;

    /**
     * 根据图片路径名下载文件
     * @param imageName 想要下载的文件的路径
     * @return 存有文件数据的字节数组
     */
    @GetMapping(value = "/avatar", produces = {MediaType.IMAGE_JPEG_VALUE,MediaType.IMAGE_GIF_VALUE, MediaType.IMAGE_PNG_VALUE})
    @ResponseBody
    public byte[] findAvatar(String imageName) throws IOException {
        System.out.println("[/download/avatar] Start...");
        // 判断图片文件名中是否包含多级目录
        if (StringUtils.isEmpty(imageName)|| imageName.contains("/") || imageName.contains("\\") || imageName.contains("./") || imageName.contains(".\\")){
            // 是：存在安全风险
            // 不做处理，直接抛出404对应的异常
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,"not found");
        }
        // 组合生成文件的绝对路径
        String osName = System.getProperty("os.name").toLowerCase();
        String delim = "";
        if (osName.equals("windows")) {
            delim = "\\";
        } else if (osName.equals("linux")) {
            delim = "/";
        }
        File file = new File(fileDir+ delim +imageName);
        System.out.println("[/download/avatar] File Path: " + file.getAbsolutePath());
        // 文件不存在
        if (file.exists()==false){
            // 抛出404对应的异常
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,"not found");
        }
        // 将文件数据写入数组
        FileInputStream inputStream = new FileInputStream(file);
        byte[] bytes =new byte[inputStream.available()];
        inputStream.read(bytes,0,inputStream.available());
        return bytes;
    }
}