package cn.seu.store.service.impl;

import cn.seu.store.mapper.UserMapper;
import cn.seu.store.service.IUserService;
import cn.seu.store.common.Constant;
import cn.seu.store.entity.User;
import cn.seu.store.service.ex.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.UUID;

@Service
public class UserServiceImpl implements IUserService {

    @Autowired(required = false)
    UserMapper mapper;

    @Override
    public void changeAvatar(Integer id, String avatar, String modifiedUser)
            throws RecordNotFoundException, UpdateException {
        // 使用id查询用户数据
        User user=findById(id);
        // 更新用户头像
        Integer row=mapper.updateAvatar(id, avatar, modifiedUser, new Date());
        // 判断受影响的行数是否不为1
        if(!row.equals(1)) {
            // 是：UpdateException
            throw new UpdateException("上传头像异常！请联系管理员");
        }
    }

    @Override
    public User findById(Integer id) throws RecordNotFoundException {
        // TODO 非空和格式验证
        // 根据uid查询用户信息
        User user=mapper.getById(id);
        // 判断是否返回null
        if(user==null) {
            // 是：RecordNotFoundException
            throw new RecordNotFoundException("查询用户信息异常！数据不存在");
        }
        // 判断is_delete是否为1
        if(user.getIsDelete().equals(Constant.IS_DELETE)) {
            // 是：RecordNotFoundException
            throw new RecordNotFoundException("查询用户信息异常！数据不存在");
        }
        // 返回用户信息(新的User对象)
        return user;
    }

    @Override
    @Transactional
    public void changeInfo(Integer id, String username, User user) throws RecordNotFoundException, UpdateException {
        // 根据id查用户信息
        // 这里调用的是业务层方法，该方法会验证用户数据是否存在
        findById(id);
        // 将uid添加到user的uid中
        user.setId(id);
        // 将username添加到user的modifiedUser中
        user.setModifiedUser(username);
        // 向user中添加更新时间
        user.setModifiedTime(new Date());
        // 更新用户数据
        // 获取受影响的行数
        Integer row=mapper.updateInfo(user);
        // 判断是否不为1
        if(!row.equals(1)) {
            // 是：UpdateException
            throw new UpdateException("更新用户信息异常！请联系管理员");
        }
    }

    @Override
    public void changePassword(String username, String oldPassword,
                               String newPassword, String modifiedUser)
            throws EmptyArgumentException, ChangePasswordException, UpdateException {
        // 非空验证 略
        // 基于usename查询用户信息
        User user=null;
        try{
            user=mapper.getByUsername(username);
        }catch(Exception e){
            e.printStackTrace();
            throw new ChangePasswordException("修改密码异常："+e.getMessage(),e);
        }
        // 判断是否没查询到信息
        if(user==null){
            // 是：ChangePasswordException
            throw new ChangePasswordException("修改密码异常：该用户不存在");
        }

        // 判断用户是否已被标记为删除
        if(user.getIsDelete()==1){
            // 是：ChangePasswordException
            throw new ChangePasswordException("修改密码异常：该用户不存在");
        }

        // 判断新旧密码是否一致
        if(oldPassword.equals(newPassword)){
            // 是：ChangePasswordException
            throw new ChangePasswordException("修改密码异常：新密码不能与旧密码一致");
        }

        // 基于查询到的盐值对用户传入的旧密码进行加密
        String oldMD5Pwd=getMD5Password(oldPassword,user.getSalt(),Constant.MD5_HASH_TIMES);
        // 判断加密后的旧密码与查询到的密码是否不一致
        if(!oldMD5Pwd.equals(user.getPassword())){
            // 是：ChangePasswordException
            throw new ChangePasswordException("修改密码异常：旧密码错误");
        }

        // 基于查询到的盐值对新密码进行加密
        String newMD5Pwd=getMD5Password(newPassword,user.getSalt(),Constant.MD5_HASH_TIMES);
        int row=0;
        try{
            // 调用持久层方法，更新密码
            row=mapper.updatePassword(user.getId(),newMD5Pwd,modifiedUser,new Date());
        }catch (Exception e){
            e.printStackTrace();
            throw new ChangePasswordException("修改密码异常："+e.getMessage(),e);
        }
        // 判断返回值结果是否不为1
        if(row!=1){
            // 是：UpdateException
            throw new UpdateException("修改密码异常：新密码设置失败");
        }
    }

    @Override
    public User login(String username, String password)
            throws EmptyArgumentException, LoginException {
        // 参数验证
        if(StringUtils.isEmpty(username)){
            throw new EmptyArgumentException("登录异常：用户名不能为空");
        }
        if(StringUtils.isEmpty(password)){
            throw new EmptyArgumentException("登录异常：密码不能为空");
        }
        // 基于用户名查用户数据
        User user=null;
        try{
            user=mapper.getByUsername(username);
        }catch (Exception e){
            e.printStackTrace();
            throw new LoginException("登录异常："+e.getMessage(),e);
        }
        // 查不到 -> 登录失败->抛异常 LoginException
        if(user==null){
            throw new LoginException("登录异常：用户名或密码错误");
        }
        // 对用户传入的密码进行加密
        String salt=user.getSalt();
        String md5Pwd=getMD5Password(password,salt,Constant.MD5_HASH_TIMES);
        // 比对两个密码
        if(!md5Pwd.equals(user.getPassword())){
            // 不一致 -> 抛异常 LoginException
            throw new LoginException("登录异常：用户名或密码错误");
        }
        // 判断用户是否已被删除
        if(user.getIsDelete().equals(Constant.IS_DELETE)){
            throw new LoginException("登录异常：用户名或密码错误");
        }
        // 将敏感信息(密码、盐值)置null
        user.setPassword(null);
        user.setSalt(null);
        // 返回userEntity对象
        return user;
    }

    @Override
    public void regist(User user)
            throws EmptyArgumentException, UserExistException,
            InsertException {
        // 判断user是否为null
        if(user==null){
            // 是：EmptyArgumentException
            throw new EmptyArgumentException("注册异常：用户信息为空");
        }

        // 判断用户名或密码是否为空
        if(StringUtils.isEmpty(user.getUsername())){
            // 是：EmptyArgumentException
            throw new EmptyArgumentException("注册异常：用户名为空");
        }
        if(StringUtils.isEmpty(user.getPassword())){
            // 是：EmptyArgumentException
            throw new EmptyArgumentException("注册异常：密码为空");
        }

        // 判断用户名是否存在
        User entity=null;
        try{
            entity=mapper.getByUsername(user.getUsername());
        }catch (Exception e){
            e.printStackTrace();
            throw new InsertException("注册异常：查询用户名异常",e);
        }
        if(entity!=null){
            // 是：UserExistException
            throw new UserExistException("注册异常：用户名已存在");
        }

        // 对密码进行加密
        // 生成盐值
        String salt= UUID.randomUUID().toString();
        // 基于盐值对密码进行加密
        String md5Password=getMD5Password(user.getPassword(),salt,Constant.MD5_HASH_TIMES);
        // 将加密信息添加到user中
        user.setPassword(md5Password);
        user.setSalt(salt);
        // 设置性别为未知
        user.setGender(Constant.USER_GENDER_UNKNOWN);

        // 将user中的is_delete设为0
        user.setIsDelete(Constant.IS_NOT_DELETE);
        // 向user中设置createdUser和modifiedUser
        user.setCreatedUser(user.getUsername());
        user.setModifiedUser(user.getUsername());
        // 调用持久层方法，添加用户数据
        int row=0;
        try{
            row=mapper.insertUser(user);
        }catch (Exception e){
            e.printStackTrace();
            throw new InsertException("注册异常：添加用户信息异常",e);
        }
        // 判断返回值是否不为1
        if(row!=1){
            // 是：InsertException
            throw new InsertException("注册异常：添加用户信息失败");
        }
    }

    /**
     * 对密码进行加密
     * @param password 原始密码
     * @param salt 盐值
     * @param time hash迭代次数
     * @return 加密后的密码
     */
    public String getMD5Password(String password,String salt,int time){
        // 组合明文和盐值
        password=password+salt+password;
        // 进行hash迭代
        for(int i=1;i<=time;i++){
            password= DigestUtils.md5DigestAsHex(password.getBytes());
        }
        return password;
    }
}