package cn.seu.store.controller;

import cn.seu.store.service.IOrderService;
import cn.seu.store.common.Constant;
import cn.seu.store.entity.JsonResult;
import cn.seu.store.entity.Order;
import cn.seu.store.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 处理订单相关请求的控制器类
 */
@RestController
@RequestMapping("/orders")
public class OrderController {
    /**
     * 订单模块的业务层接口
     */
    @Autowired
    IOrderService service;

    /**
     * 基于用户id获取该用户的全部订单
     * @param session 会话
     * @return {@link Order} 订单列表
     */
    @RequestMapping("/list")
    public JsonResult<List<Order>> findOrder(HttpSession session){
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        List<Order> data=service.findByUid(user.getId());
        return JsonResult.getSuccessJR(data);
    }

    /**
     * 基于用户id，为该用户创建订单
     * @param aid 收货地址记录id
     * @param cids 购物车记录id数组
     * @param session 会话
     * @return {@link Integer} 订单id
     */
    @RequestMapping("/create")
    public JsonResult<Integer> createOrder(Integer aid, Integer[] cids, HttpSession session) {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        Integer data = service.createOrder(aid, cids, user.getId(), user.getUsername());
        return JsonResult.getSuccessJR(data);
    }

    /**
     * 基于订单id获取订单记录
     * @param oid 订单id
     * @return {@link Order} 订单信息
     */
    @RequestMapping("/getByOid")
    public JsonResult<Order> getOrderByOid(Integer oid) {
        Order order = service.getByOid(oid);
        return JsonResult.getSuccessJR(order);
    }

    /**
     * 获取订单最长允许支付的时间
     * @return {@link Integer} 订单最长允许支付的时间
     */
    @RequestMapping("/getOrderTimeout")
    public JsonResult<Integer> getOrderTimeout() {
        return JsonResult.getSuccessJR(Constant.ORDER_TIMEOUT_MINUTES);
    }

    /**
     * 基于订单id，修改该订单的状态
     * @param oid 订单id
     * @param status 订单状态，0-未支付 1-已支付 2-已取消 3-已超时 4-已收货
     * @param session 会话
     * @return Void
     */
    @RequestMapping("/changeStatus")
    public JsonResult<Void> changeStatus(Integer oid, Integer status, HttpSession session) {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        service.changeStatus(oid, status, user.getUsername());
        return JsonResult.getSuccessJR();
    }
}
