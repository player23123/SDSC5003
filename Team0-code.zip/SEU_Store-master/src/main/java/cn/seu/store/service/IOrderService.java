package cn.seu.store.service;

import cn.seu.store.entity.Order;
import cn.seu.store.service.ex.*;

import java.util.Date;
import java.util.List;

public interface IOrderService {
    /**
     * 基于用户id查询订单记录
     * @param uid
     * @return
     */
    List<Order> findByUid(Integer uid);

    /**
     * 基于订单id关闭订单支付窗口
     * @param oid
     * @param username
     */
    void closeOrder(Integer oid,String username)
            throws RecordNotFoundException, UpdateException;

    /**
     * 基于订单id修改订单状态
     * @param oid
     * @param status 0-未支付 1-已支付 2-已取消 3-已超时
     * @param username
     * @throws UpdateException
     */
    void changeStatus(Integer oid, Integer status, String username)
            throws RecordNotFoundException, UpdateException;

    /**
     * 添加一条订单记录
     * 生成多条关联的订单项记录
     * @param aid
     * @param cids
     * @param uid
     * @param username
     * @return
     */
    Integer createOrder(Integer aid,Integer[] cids, Integer uid,String username)
            throws RecordNotFoundException, ProductOutOfStockException, UpdateException,
            InsertException, DeleteException;

    /**
     * 基于订单id查询一条订单记录
     * @param oid
     * @return
     * @throws RecordNotFoundException
     */
    Order getByOid(Integer oid) throws RecordNotFoundException;

    /**
     * 基于订单id支付订单
     * @param oid
     * @param payTime
     * @param username
     * @throws RecordNotFoundException
     * @throws UpdateException
     */
    void payOrder(Integer oid, Date payTime, String username)
            throws RecordNotFoundException, UpdateException;
}
