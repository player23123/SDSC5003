package cn.seu.store.service.impl;


import cn.seu.store.common.Constant;
import cn.seu.store.entity.*;
import cn.seu.store.mapper.OrderMapper;
import cn.seu.store.service.*;
import cn.seu.store.service.ex.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

@Service
public class OrderServiceImpl implements IOrderService {

    @Autowired(required = false)
    OrderMapper mapper;
    @Autowired
    IUserService userService;
    @Autowired
    ICartService cartService;
    @Autowired
    IProductService productService;
    @Autowired
    IAddressService addressService;

    private final ScheduledExecutorService scheduler =
            Executors.newScheduledThreadPool(3);

    @Override
    public List<Order> findByUid(Integer uid) {
        return mapper.listByUid(uid);
    }

    /**
     * 启动一个一次性延迟任务的方法
     * @param oid
     */
    public void delayCloseOrder(Integer oid, String username) {
        System.err.println("计时器启动："+new Date()+":"+oid);
        Runnable runner = new MyRunner(oid, username);
        ScheduledFuture<?> handle =
                scheduler.schedule(runner, Constant.ORDER_TIMEOUT_MINUTES, TimeUnit.MINUTES);
    }

    /**
     * 自定义的Runnable接口实现类
     * 用于封装一次性计时器到期时执行的逻辑
     * 在这里是调用closeOrder方法，关闭订单
     */
    class MyRunner implements Runnable{

        private Integer oid;
        private String username;

        public MyRunner(Integer oid,String username){
            this.oid=oid;
            this.username=username;
        }

        @Override
        public void run() {
            closeOrder(this.oid,this.username);
        }
    };

    @Override
    public void closeOrder(Integer oid,String username)
            throws RecordNotFoundException, UpdateException {
        System.err.println("closeOrder:"+oid+":"+new Date());
        // 基于oid查询订单状态
        Order order=mapper.getById(oid);
        if(order==null){
            throw new RecordNotFoundException("关闭订单异常：订单记录不存在");
        }
        Integer orderStatus = order.getStatus();
        if(orderStatus.equals(Constant.ORDER_STATUS_UNPAID)){
            // 如果是未支付-> 修改状态为超时 3
            changeStatus(oid,Constant.ORDER_STATUS_TIMEOUT,username);
            // 归还订单的库存
            List<OrderItem> orderItems=order.getOrderItems();
            for(OrderItem item:orderItems){
                productService.increaseProductNum(item.getProductId(),item.getNum(),true);
            }
        } else if (orderStatus.equals(Constant.ORDER_STATUS_TIMEOUT)) {
            // 归还订单的库存
            List<OrderItem> orderItems=order.getOrderItems();
            for(OrderItem item:orderItems){
                productService.increaseProductNum(item.getProductId(),item.getNum(), true);
            }
        }
    }

    @Override
    public void changeStatus(Integer oid, Integer status, String username)
            throws UpdateException {
        // 基于oid查询订单状态
        Order order=mapper.getById(oid);
        if(order==null){
            throw new RecordNotFoundException("更新订单状态异常：订单记录不存在");
        }
        Integer row=mapper.updateStatus(oid,status,username,new Date());
        if(row!=1){
            throw new UpdateException("更新订单状态异常：数据更新失败");
        }
    }

    @Override
    public void payOrder(Integer oid, Date payTime, String username)
            throws RecordNotFoundException, UpdateException {
        // 基于oid查询订单状态
        Order order=mapper.getById(oid);
        if(order==null){
            throw new RecordNotFoundException("支付订单异常：订单记录不存在");
        }
        // 支付订单
        Integer row = mapper.payOrder(oid, payTime, username, new Date());
        if (row!=1){
            throw new UpdateException("支付订单异常：数据更新失败");
        }
    }

    @Override
    @Transactional
    public Integer createOrder(Integer aid, Integer[] cids, Integer uid, String username)
            throws RecordNotFoundException, ProductOutOfStockException, UpdateException,
            InsertException, DeleteException {
        // 创建当前时间对象
        Date now=new Date();
        // 参数验证 TODO
        // 逻辑外键：
        // 验证uid和cid存在
        User user=userService.findById(uid);
        if(user==null){
            throw new RecordNotFoundException("添加订单异常：用户信息不存在");
        }
        // 基于cids查询购物车记录
        List<CartVO> cartList=cartService.findByCids(cids,uid);
        // 判断返回值长度是否与cids长度不一致
        if(cartList.size()!=cids.length){
            // 是：RecordNotFoundException
            throw new RecordNotFoundException("添加订单异常：购物车项不存在");
        }
        // 验证aid
        // 基于aid查询收货地址记录
        Address address=addressService.findByAid(aid);
        // 判断返回值是否为null
        if(address==null){
            // 是：RecordNotFoundException
            throw new RecordNotFoundException("添加订单异常：收货地址不存在");
        }

        // 销库存
        // 遍历查询到的购物车记录
        for(CartVO cartVO:cartList){
            // 调用业务层方法，减少对应商品的库存
            productService.reduceProductNum(cartVO.getPid(),cartVO.getNum(),true);
        }

        // 添加订单记录
        // 创建订单对象
        Order order=new Order();
        // 向订单对象中添加uid
        order.setUserId(uid);
        // 向订单对象中添加收货地址相关信息
        order.setRecvProvince(address.getProvinceName());
        order.setRecvCity(address.getCityName());
        order.setRecvArea(address.getAreaName());
        order.setRecvAddress(address.getAddress());
        order.setRecvName(address.getName());
        order.setRecvPhone(address.getPhone());
        // 基于购物车记录计算订单总价格
        long totalPrice=0L;
        // 遍历查询到的购物车记录
        for(CartVO cartVO:cartList){
            totalPrice+=cartVO.getRealPrice()*cartVO.getNum();
        }
        // 向订单对象中添加订单总价格
        order.setTotalPrice(totalPrice);
        // 设置订单状态为未支付
        order.setStatus(Constant.ORDER_STATUS_UNPAID);
        // 设置订单为未删除
        order.setIsDelete(Constant.IS_NOT_DELETE);
        // 向订单对象中添加日志信息
        order.setOrderTime(now);
        order.setCreatedTime(now);
        order.setCreatedUser(username);
        order.setModifiedTime(now);
        order.setModifiedUser(username);
        // 调用持久层方法添加订单记录
        Integer row=mapper.insertOrder(order);
        // 判断返回值结果是否不为1 或 订单对象中的id是否为null
        if(row!=1 || order.getId()==null){
            // 是：InsertException
            throw new InsertException("添加订单异常：订单添加失败");
        }

        // 添加订单项记录
        // 遍历查询到的购物车记录
        for(CartVO cartVO:cartList){
            // 创建订单项对象
            OrderItem item=new OrderItem();
            // 向订单项对象中添加商品信息
            item.setProductId(cartVO.getPid());
            item.setNum(cartVO.getNum());
            item.setImage(cartVO.getImage());
            item.setTitle(cartVO.getTitle());
            item.setPrice(cartVO.getRealPrice());
            // 向订单项对象中添加订单id
            item.setOrderId(order.getId());
            // 向订单项对象中添加日志信息
            item.setCreatedTime(now);
            item.setCreatedUser(username);
            item.setModifiedTime(now);
            item.setModifiedUser(username);
            // 调用持久层方法，添加一条订单项记录
            Integer row2=mapper.insertOrderItem(item);
            // 判断返回值是否不为1
            if(row2!=1){
                // 是：InsertException
                throw new InsertException("添加订单异常：订单项添加失败");
            }
        }
        // 基于cids删除购物车记录
        cartService.removeCartList(cids);
        // 订单的限时支付
        delayCloseOrder(order.getId(),username);

        return order.getId();
    }

    @Override
    public Order getByOid(Integer oid) throws RecordNotFoundException {
        Order order = mapper.getById(oid);
        if (order == null) {
            throw new RecordNotFoundException("查询订单异常：订单不存在");
        }
        return order;
    }
}
