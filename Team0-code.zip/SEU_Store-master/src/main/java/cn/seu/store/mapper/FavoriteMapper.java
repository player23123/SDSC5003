package cn.seu.store.mapper;

import cn.seu.store.entity.Favorite;

import cn.seu.store.entity.FavoriteVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * 收藏模块的持久层接口
 */
@Mapper
public interface FavoriteMapper {
    /**
     * 基于用户id和商品id查询收藏记录
     * @param uid
     * @param pid
     * @return
     */
    Favorite getByUidAndPid(@Param("uid") Integer uid,
                            @Param("pid") Integer pid);

    /**
     * 基于用户id查询所有收藏记录
     * @param uid
     * @return
     */
    List<FavoriteVO> getFavoriteList(Integer uid);

    /**
     * 添加一条收藏记录
     * @param favorite
     * @return
     */
    Integer insertFavorite(Favorite favorite);

    /**
     * 更新收藏记录
     * @param fid
     * @param username
     * @return
     */
    Integer updateFavorite(@Param("fid") Integer fid,
                           @Param("username") String username);

    /**
     * 基于用户id和商品id删除收藏记录
     * @param uid
     * @param pid
     * @return
     */
    Integer deleteFavoriteByUidAndPid(@Param("uid") Integer uid,
                                      @Param("pid") Integer pid);
}
