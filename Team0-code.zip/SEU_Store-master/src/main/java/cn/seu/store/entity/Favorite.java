package cn.seu.store.entity;

import java.util.Date;

/**
 * 封装收藏信息的实体类
 */
public class Favorite {
    private Integer id;
    private Integer userId;
    private Integer productId;
    private String createdUser;
    private Date createdTime;
    private String modifiedUser;
    private Date modifiedTime;

    public Favorite() {

    }

    public Favorite(Integer id, Integer userId, Integer productId,
                    String createdUser, Date createdTime,
                    String modifiedUser, Date modifiedTime) {
        this.id = id;
        this.userId = userId;
        this.productId = productId;
        this.createdUser = createdUser;
        this.modifiedUser = modifiedUser;
        this.createdTime = createdTime;
        this.modifiedTime = modifiedTime;
    }

    public Integer getId() { return id; }

    public void setId(Integer id) { this.id = id; }

    public Integer getUserId() { return userId; }

    public void setUserId(Integer userId) { this.userId = userId; }

    public Integer getProductId() { return productId; }

    public void setProductId(Integer product) { this.productId = product; }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public String getModifiedUser() {
        return modifiedUser;
    }

    public void setModifiedUser(String modifiedUser) {
        this.modifiedUser = modifiedUser;
    }

    public Date getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    @Override
    public String toString() {
        return "Favorite{" +
                "id=" + id +
                ", userId=" + userId +
                ", productId=" + productId +
                ", createdUser='" + createdUser + '\'' +
                ", createdTime=" + createdTime +
                ", modifiedUser='" + modifiedUser + '\'' +
                ", modifiedTime=" + modifiedTime +
                "}";
    }
}
