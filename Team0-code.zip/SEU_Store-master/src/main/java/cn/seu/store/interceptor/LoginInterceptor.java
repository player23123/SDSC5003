package cn.seu.store.interceptor;

import cn.seu.store.common.Constant;
import cn.seu.store.entity.User;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 登录拦截器
 * 需要登录才能放行
 */
@Component
public class LoginInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 判断用户是否已登录
        HttpSession session=request.getSession();
        User user=(User) session.getAttribute(Constant.SESSION_USER);
        if(user!=null){ // 已登录
            return true; // 放行
        }
        String path=request.getServletContext().getContextPath();
        // 重定向到登录页面
        response.sendRedirect(path+"/web/login.html");
        return false;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}
