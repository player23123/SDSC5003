package cn.seu.store.controller;

import cn.seu.store.entity.*;
import cn.seu.store.service.IProductService;
import cn.seu.store.common.Constant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 处理商品相关请求的控制器类
 */
@RestController
@RequestMapping("/products")
public class ProductController {
    /**
     * 商品模块的业务层接口
     */
    @Autowired
    IProductService service;

    /**
     * 基于商品名称查找商品
     * @param name 商品名称
     * @param currentPage 当前页码
     * @param pageSize 总页数
     * @return {@link PageRecord} 商品信息列表（一页）
     */
    @GetMapping("/findProductByName")
    public JsonResult<PageRecord> findProductByName(
            String name, Integer currentPage, Integer pageSize){
        return JsonResult.getSuccessJR(service.findProductByName(name,currentPage,pageSize));
    }

    /**
     * 基于用户id，获取为该用户推荐的商品（基于用户的访问记录）
     * @param session 会话
     * @return {@link Product} 商品列表
     */
    @GetMapping("/favourite")
    public JsonResult<List<Product>> findFavourite(HttpSession session){
        User user=(User)session.getAttribute(Constant.SESSION_USER);
        if (user==null || user.getId()==null){
            return new JsonResult<>(2005,"登录状态已超时");
        }
        List<Product> data = service.findFavourite(user.getId());
        return JsonResult.getSuccessJR(data);
    }

    /**
     * 基于商品种类，获取商品列表
     * @param cid 商品种类id
     * @param currentPage 当前页码
     * @param pageSize 总页数
     * @return {@link PageRecord} 商品信息列表（一页）
     */
    @GetMapping("/findProductByCid")
    public JsonResult<PageRecord> findProductByCid(
            Integer cid, Integer currentPage, Integer pageSize){
        return JsonResult.getSuccessJR(service.findProductByCid(cid,currentPage,pageSize));
    }

    /**
     * 获取所有商品种类
     * @return {@link ProductCategory} 商品种类列表
     */
    @GetMapping("/findAllCategory")
    public JsonResult<List<ProductCategory>> findAllCategory(){
        return JsonResult.getSuccessJR(service.findAllCategory());
    }

    /**
     * 基于商品id，查找商品
     * @param id 商品id
     * @return {@link Product} 商品信息
     */
    @GetMapping("/{id}/get")
    public JsonResult<Product> findById(@PathVariable("id") Integer id){
        Product product=service.findById(id);
        return JsonResult.getSuccessJR(product);
    }

    /**
     * 获取最热销的商品
     * @return {@link Product} 商品列表
     */
    @GetMapping("/hot")
    public JsonResult<List<Product>> getHotList(){
        // 查询
        List<Product> data = service.findHotList();
        // 返回
        return JsonResult.getSuccessJR(data);
    }
}
