package cn.seu.store.service.impl;

import cn.seu.store.common.Constant;
import cn.seu.store.mapper.UserOptMapper;
import cn.seu.store.service.IProductService;
import cn.seu.store.entity.PageRecord;
import cn.seu.store.entity.Product;
import cn.seu.store.entity.ProductCategory;
import cn.seu.store.mapper.ProductMapper;
import cn.seu.store.service.ex.EmptyArgumentException;
import cn.seu.store.service.ex.ProductOutOfStockException;
import cn.seu.store.service.ex.RecordNotFoundException;
import cn.seu.store.service.ex.UpdateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProductServiceImpl implements IProductService {

    @Autowired(required = false)
    ProductMapper mapper;

    @Autowired(required = false)
    UserOptMapper optMapper;
    // 默认的商品种类id
    private static final Integer DEFAULT_CID=163;

    @Override
    public PageRecord<List<Product>> findProductByName(String name, Integer currentPage, Integer pageSize) throws RecordNotFoundException {
        // 非空验证 TODO
        // 查询总数据条数
        Integer count=mapper.getCountByName(name);
        // 判断结果是否为0
        if(count==0){
            // 是：RecordNotFoundException
            throw new RecordNotFoundException("分页查询商品异常：未查到相关记录");
        }
        // 超过上限则使用上限
        if(pageSize> Constant.MAX_PAGE_SIZE){
            pageSize=Constant.MAX_PAGE_SIZE;
        }
        // 计算recordIndex=(currentPage-1)*pageSize
        Integer recordIndex=(currentPage-1)*pageSize;
        // 查询当前页记录
        List<Product> data=mapper.listAllByName(name,recordIndex,pageSize);
        // 判断结果是否为null 或 长度是否为0
        if(data==null || data.size()==0){
            // 是：RecordNotFoundException
            throw new RecordNotFoundException("分页查询商品异常：未查到当前页记录");
        }

        // 计算pageCount=(count-1)/pageSize+1
        Integer pageCount=(count-1)/pageSize+1;
        // 创建PageRecord，封装数据
        PageRecord<List<Product>> pageRecord =
                new PageRecord<>(pageSize,count,pageCount,currentPage,data);
        // 返回PageRecord
        return pageRecord;
    }


    @Override
    public Product findByIdInner(Integer id) throws EmptyArgumentException, RecordNotFoundException {
        if(id==null){
            throw new EmptyArgumentException("查询商品数据异常：id不能为空");
        }
        Product product=mapper.getById(id);
        if (product==null){
            throw new RecordNotFoundException("查询商品数据异常：未查到该商品数据");
        }
        // 将不需要给用户的数据设为null
        product.setPriority(null);
        // product.setStatus(null);
        product.setCreatedUser(null);
        product.setCreatedTime(null);
        product.setModifiedUser(null);
        product.setModifiedTime(null);
        return product;
    }

    @Override
    @Transactional
    public void increaseProductNum(Integer pid, Integer num) throws RecordNotFoundException, UpdateException {
        increaseProductNum(pid, num, false);
    }
    @Override
    @Transactional
    public void increaseProductNum(Integer pid, Integer num, Boolean updatePriority) throws RecordNotFoundException, UpdateException {
        Product product=mapper.getByIdForUpdate(pid);
        if(product==null){
            throw new RecordNotFoundException("增加商品库存异常：商品不存在");
        }
        int newNum=product.getNum()+num;
        if(product.getNum()==0 && product.getStatus()==Constant.PRODUCT_STATUS_OFFSALE){
            // 商品重新上架
            Integer row = mapper.updateStatusById(pid,Constant.PRODUCT_STATUS_ONSALE);
            if(row!=1){
                throw new UpdateException("增加商品库存异常：商品状态更新失败");
            }
        }
        Integer row=mapper.updateNumById(pid,newNum);
        if(row!=1){
            throw new UpdateException("增加商品库存异常：库存更新失败");
        }

        if (!updatePriority) {
            return;
        }
        int newPriority = product.getPriority() - num;
        row = mapper.updatePriorityById(pid,newPriority);
        if(row!=1){
            throw new UpdateException("更新商品优先级异常：优先级更新失败");
        }
    }

    @Override
    @Transactional
    public void reduceProductNum(Integer pid,Integer num)
            throws RecordNotFoundException, ProductOutOfStockException, UpdateException {
        reduceProductNum(pid, num, false);
    }
    @Override
    @Transactional
    public void reduceProductNum(Integer pid, Integer num, Boolean updatePriority)
            throws RecordNotFoundException, ProductOutOfStockException, UpdateException {
        Product product=mapper.getByIdForUpdate(pid);
        if(product==null){
            throw new RecordNotFoundException("减少商品库存异常：商品不存在");
        }
        int newNum=product.getNum()-num;
        if(newNum<0){
            throw new ProductOutOfStockException("减少商品库存异常：商品库存不足");
        }else if(newNum==0 && product.getStatus()==Constant.PRODUCT_STATUS_ONSALE){
            // 商品下架
            Integer row = mapper.updateStatusById(pid,Constant.PRODUCT_STATUS_OFFSALE);
            if(row!=1) {
                throw new UpdateException("减少商品库存异常：商品状态更新失败");
            }
        }
        Integer row=mapper.updateNumById(pid,newNum);
        if(row!=1){
            throw new UpdateException("减少商品库存异常：库存更新失败");
        }

        if (!updatePriority) {
            return;
        }
        int newPriority = product.getPriority() + num;
        row = mapper.updatePriorityById(pid,newPriority);
        if(row!=1){
            throw new UpdateException("更新商品优先级异常：优先级更新失败");
        }
    }

    @Override
    public List<Product> findFavourite(Integer uid) {
        // 基于uid查询用户近7天访问最多的商品种类
        Integer cid=optMapper.getCidByUid(uid);
        if(cid==null){
            cid=DEFAULT_CID;
        }
        // 基于cid随机查询4种商品信息
        List<Product> list=mapper.listByCid(cid);
        return list;
    }

    @Override
    public PageRecord<List<Product>> findProductByCid(
            Integer cid, Integer currentPage, Integer pageSize)
            throws RecordNotFoundException {
        // 非空验证 TODO
        // 查询总数据条数
        Integer count=mapper.getCountByCid(cid);
        // 判断结果是否为0
        if(count==0){
            // 是：RecordNotFoundException
            throw new RecordNotFoundException("分页查询商品异常：未查到相关记录");
        }
        // 超过上限则使用上限
        if(pageSize> Constant.MAX_PAGE_SIZE){
            pageSize=Constant.MAX_PAGE_SIZE;
        }
        // 计算recordIndex=(currentPage-1)*pageSize
        Integer recordIndex=(currentPage-1)*pageSize;
        // 查询当前页记录
        List<Product> data=mapper.listAllByCid(cid,recordIndex,pageSize);
        // 判断结果是否为null 或 长度是否为0
        if(data==null || data.size()==0){
            // 是：RecordNotFoundException
            throw new RecordNotFoundException("分页查询商品异常：未查到当前页记录");
        }

        // 计算pageCount=(count-1)/pageSize+1
        Integer pageCount=(count-1)/pageSize+1;
        // 创建PageRecord，封装数据
        PageRecord<List<Product>> pageRecord =
                new PageRecord<>(pageSize,count,pageCount,currentPage,data);
        // 返回PageRecord
        return pageRecord;
    }

    @Override
    public List<ProductCategory> findAllCategory() {
        return mapper.listAllCategory();
    }

    @Override
    public Product findById(Integer id) throws EmptyArgumentException, RecordNotFoundException {
        if(id==null){
            throw new EmptyArgumentException("查询商品数据异常：id不能为空");
        }
        Product product=mapper.getById(id);
        if (product==null){
            throw new RecordNotFoundException("查询商品数据异常：未查到该商品数据");
        }
        // 将不需要给用户的数据设为null
        product.setPriority(null);
        // product.setStatus(null);
        product.setCreatedUser(null);
        product.setCreatedTime(null);
        product.setModifiedUser(null);
        product.setModifiedTime(null);
        return product;
    }

    @Override
    public List<Product> findHotList() {
        return mapper.listHotProduct();
    }

}
