package cn.seu.store.controller;

import cn.seu.store.entity.Cart;
import cn.seu.store.entity.CartVO;
import cn.seu.store.service.ICartService;
import cn.seu.store.common.Constant;
import cn.seu.store.entity.JsonResult;
import cn.seu.store.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 处理购物车相关请求的控制器类
 */
@RestController
@RequestMapping("/carts")
public class CartController {
    /**
     * 购物车模块的业务层接口
     */
    @Autowired
    ICartService service;

    /**
     * 基于购物车记录id，获取对应的购物车信息列表
     * @param cids 购物车id数组
     * @param session 会话
     * @return {@link CartVO} 购物车信息列表
     */
    @GetMapping("/findByCids")
    public JsonResult<List<CartVO>> findByCids(Integer[] cids, HttpSession session){
        User user=(User)session.getAttribute(Constant.SESSION_USER);
        List<CartVO> data=service.findByCids(cids,user.getId());
        return JsonResult.getSuccessJR(data);
    }

    /**
     * 基于购物车记录id，修改该购物车记录的商品数量
     * @param cid 购物车记录id
     * @param num 新的购物车商品数量
     * @param session 会话
     * @return Void
     */
    @PostMapping("/changeNum")
    public JsonResult<Void> changeNum(Integer cid, Integer num,HttpSession session){
        User user=(User)session.getAttribute(Constant.SESSION_USER);
        service.changeNum(cid,num,user.getId(),user.getUsername());
        return JsonResult.getSuccessJR();
    }

    /**
     * 基于购物车id，批量删除购物车记录
     * @param cids 购物车记录id数组
     * @return Void
     */
    @PostMapping("/removeList")
    public JsonResult<Void> removeCartList(Integer[] cids){
        service.removeCartList(cids);
        return JsonResult.getSuccessJR();
    }

    /**
     * 基于购物车id，删除一条购物车记录
     * @param cid 购物车记录id
     * @param session 会话
     * @return Void
     */
    @PostMapping("/remove")
    public JsonResult<Void> removeCart(Integer cid,HttpSession session){
        User user=(User)session.getAttribute(Constant.SESSION_USER);
        service.removeCart(cid,user.getId());
        return JsonResult.getSuccessJR();
    }

    /**
     * 基于用户id，获取该用户的购物车列表
     * @param session 会话
     * @return {@link CartVO} 购物车信息列表
     */
    @GetMapping("/list")
    public JsonResult<List<CartVO>> findCartList(HttpSession session){
        User user=(User)session.getAttribute(Constant.SESSION_USER);
        List<CartVO> list=service.findCartList(user.getId());
        return JsonResult.getSuccessJR(list);
    }

    /**
     * 基于商品id和数量，为用户创建一条购物车记录
     * @param product_id 商品id
     * @param num 商品数量
     * @param session 会话
     * @return Void
     */
    @RequestMapping("/create")
    public JsonResult<Void> createCart(Integer product_id, Integer num,
                                       HttpSession session){
        User user=(User)session.getAttribute(Constant.SESSION_USER);
        service.createCart(product_id,num,user.getId(),user.getUsername());
        return JsonResult.getSuccessJR();
    }

    /**
     * 基于用户id和商品id，获取一条购物车记录
     * @param pid 商品id
     * @param session 会话
     * @return {@link Cart} 购物车记录
     */
    @RequestMapping("/getCartByPid")
    public JsonResult<Cart> getCartByPid(Integer pid, HttpSession session) {
        User user = (User)session.getAttribute(Constant.SESSION_USER);
        Cart cart = service.getCartByUidAndPid(user.getId(), pid);
        return JsonResult.getSuccessJR(cart);
    }
}
