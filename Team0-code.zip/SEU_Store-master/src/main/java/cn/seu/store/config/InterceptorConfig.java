package cn.seu.store.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class InterceptorConfig implements WebMvcConfigurer {

    @Autowired
    @Qualifier("loginInterceptor")
    HandlerInterceptor interceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // 注册拦截器
        InterceptorRegistration ir=registry.addInterceptor(interceptor);
        // 设置黑名单 /** 表示通配多级目录
        // 这里的配置思路是默认拦截对所有路径，仅放行白名单中的路径
        ir.addPathPatterns("/**");

        // 创建保存放行路径的集合
        List<String> list=new ArrayList<>();
        // 添加静态资源路径
        list.add("/bootstrap3/**");
        list.add("/css/**");
        list.add("/images/**");
        list.add("/js/**");
        list.add("/index.html");
        // 添加注册和登录页面路径
        list.add("/web/register.html");
        list.add("/web/login.html");
        list.add("/web/product.html");
        // 添加首页和页头子页面
        list.add("/web/index.html");
        list.add("/web/subpage_loggedIn.html");
        list.add("/web/subpage_notLoggedIn.html");
        // 放行对省市区信息请求
        list.add("/districts/**");
        // 放行商品相关请求
        list.add("/products/**");
        // 添加注册和登录控制器路径
        list.add("/users/regist");
        list.add("/users/login");
        list.add("/users/findUserInfo");
        // 添加白名单
        ir.excludePathPatterns(list);
    }
}
