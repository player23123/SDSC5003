package cn.seu.store.service.impl;

import cn.seu.store.common.Constant;
import cn.seu.store.entity.*;
import cn.seu.store.mapper.ProductMapper;
import cn.seu.store.mapper.UserMapper;
import cn.seu.store.mapper.UserOptMapper;
import cn.seu.store.service.IUserOptService;
import cn.seu.store.service.ex.RecordNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@Service
public class UserOptServiceImpl implements IUserOptService {
    @Autowired(required = false)
    UserOptMapper mapper;

    @Autowired(required = false)
    UserMapper userMapper;

    @Autowired(required = false)
    ProductMapper productMapper;

    @Override
    public List<UserOptVO> getUserOptsByUid(Integer uid) throws RecordNotFoundException {
        User user = userMapper.getById(uid);
        if (user == null || user.getIsDelete().equals(Constant.IS_DELETE)) {
            throw new RecordNotFoundException("获取用户行为信息异常：用户不存在");
        }
        List<UserOpt> userOpts = mapper.getUserOptsByUid(uid);
        if (userOpts == null) {
            throw new RecordNotFoundException("获取用户行为信息异常：获取失败");
        }
        List<UserOptVO> userOptsVo = new ArrayList<UserOptVO>(userOpts.size());
        for (int i = 0; i < userOpts.size(); ++i) {
            UserOpt opt = userOpts.get(i);
            UserOptVO optVO = new UserOptVO();

            Product product = productMapper.getById(opt.getProductId());
            if (product == null) {
                throw new RecordNotFoundException("获取用户行为信息异常：商品不存在, id: " + opt.getProductId());
            }
            optVO.setProductId(product.getId());
            optVO.setProductTitle(product.getTitle());

            ProductCategory productCategory = productMapper.getCategoryByCid(opt.getCategoryId());
            if (productCategory == null) {
                throw new RecordNotFoundException("获取用户行为信息异常：商品种类不存在");
            }
            optVO.setCategoryId(productCategory.getId());
            optVO.setCategoryName(productCategory.getName());

            optVO.setType(opt.getType());
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            optVO.setCreatedTime(sdf.format(opt.getCreatedTime()));
            userOptsVo.add(optVO);
        }
        return userOptsVo;
    }

    @Override
    public Product getMostOptProduct(String type) throws RecordNotFoundException {
        Integer productId = mapper.getMostOptProductId(type);
        if (productId == null) {
            return null;
        }
        Product product = productMapper.getById(productId);
        if (product == null) {
            throw new RecordNotFoundException("获取最多用户行为商品异常：商品不存在");
        }
        return product;
    }
}
