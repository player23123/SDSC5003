package cn.seu.store.controller;

import cn.seu.store.common.Constant;
import cn.seu.store.entity.JsonResult;
import cn.seu.store.entity.User;
import cn.seu.store.service.IPaymentService;
import com.alipay.api.AlipayApiException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;

/**
 * 处理支付相关请求的控制器类
 */
@RestController
@RequestMapping("/payments")
public class PaymentController {
    /**
     * 支付模块的业务层接口
     */
    @Autowired
    IPaymentService paymentService;

    /**
     * 使用支付宝支付，调用支付宝API
     * @param oid 订单id
     * @param session 会话
     * @return {@link String} 支付宝表单html文本字符串
     * @throws AlipayApiException
     */
    @RequestMapping("/alipay")
    public JsonResult<String> alipay(Integer oid, HttpSession session) throws AlipayApiException {
        User user = (User) session.getAttribute(Constant.SESSION_USER);
        String submitBody = paymentService.alipay(oid, user.getUsername());
        return JsonResult.getSuccessJR(submitBody);
    }
}
