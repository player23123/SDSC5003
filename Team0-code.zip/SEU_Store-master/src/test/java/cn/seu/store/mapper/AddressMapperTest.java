package cn.seu.store.mapper;

import cn.seu.store.entity.Address;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;
import java.util.List;

@SpringBootTest
class AddressMapperTest {

    @Autowired(required = false)
    AddressMapper mapper;

    @Test
    void listByUid() {
        List<Address> list=mapper.listByUserId(4);
        list.forEach(item-> System.err.println(item));
    }

    @Test
    void saveAddress() {
        Address address=new Address(null,
                4,"张三","福建省",1,"漳州市",2,"芗城区",3,100010,"闽南师范大学",
                "13800000000","010-56778888","学校",1,"test",null,"test",null);
        int row=mapper.saveAddress(address);
        System.err.println("row="+row);
    }

    @Test
    void countByuserId() {
        Integer count=mapper.countByUserId(4);
        System.err.println("count="+count);
    }

    @Test
    void updateDefault() {
        int row=mapper.updateDefault(7,"test1",new Date());
        System.err.println("row="+row);
    }

    @Test
    void updateNonDefault() {
        int row=mapper.updateNonDefault(4);
        System.err.println("row="+row);
    }

    @Test
    void getById() {
        System.err.println(mapper.getById(7));
    }

    @Test
    void getLastModified() {
        Address address=mapper.getLastModified(4);
        System.err.println(address);
    }

    @Test
    void deleteById() {
        int row=mapper.deleteById(6);
        System.err.println("row="+row);
    }
}