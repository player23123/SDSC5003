package cn.seu.store.service.impl;

import cn.seu.store.service.IOrderService;
import cn.seu.store.common.Constant;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class OrderServiceImplTest {

    @Autowired
    IOrderService service;

    @Test
    public void changeStatus() {
        try {
            service.changeStatus(1, Constant.ORDER_STATUS_TIMEOUT, "管理员");
        } catch (Exception e) {
            System.err.println(e.getClass().getName());
            System.err.println(e.getMessage());
        }
    }

    @Test
    void createOrder() {
        Integer aid=1;
        Integer uid=1;
        String username="test123";
        Integer[] cids=new Integer[]{3,4};
        service.createOrder(aid,cids,uid,username);
        try {
            Thread.sleep(80*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}