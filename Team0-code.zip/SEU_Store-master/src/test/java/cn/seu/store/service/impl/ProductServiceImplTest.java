package cn.seu.store.service.impl;

import cn.seu.store.service.IProductService;
import cn.seu.store.entity.PageRecord;
import cn.seu.store.entity.Product;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class ProductServiceImplTest {

    @Autowired
    IProductService service;

    @Test
    void findProductByCid() {
        PageRecord<List<Product>> record=
                service.findProductByCid(163,1,4);
        System.err.println(record);
    }

    @Test
    public void findById() {
        Product product=service.findById(10000001);
        System.err.println(product);
    }


    @Test
    void findHotList() {
        List<Product> list=service.findHotList();
        list.forEach(item-> System.err.println(item));
    }
}