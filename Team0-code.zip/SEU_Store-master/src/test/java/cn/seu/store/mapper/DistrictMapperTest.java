package cn.seu.store.mapper;

import cn.seu.store.entity.District;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class DistrictMapperTest {

    @Autowired(required = false)
    DistrictMapper mapper;

    @Test
    void listByParent() {
        List<District> list=mapper.listByParent("86");
        list.forEach(item-> System.err.println(item));
    }

    @Test
    void getNameByCode() {
        String name=mapper.getNameByCode("110000");
        System.err.println(name);
    }
}