package cn.seu.store.mapper;

import cn.seu.store.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;

@SpringBootTest
class UserMapperTest {

    @Autowired(required = false)
    UserMapper mapper;

    @Test
    public void updateAvatar() {
        Integer id=4;
        String avatar="/abc/1.jpg";
        String modifiedUser="管理员";
        Date modifiedTime=new Date();
        Integer row=mapper.updateAvatar(id, avatar, modifiedUser, modifiedTime);
        System.err.println("row="+row);
    }

    @Test
    void insertUser() {
        User user=new User();
        user.setUsername("test");
        user.setPassword("123456");
        user.setIsDelete(0);
        user.setCreatedUser("test");
        user.setModifiedUser("test");
        int row=mapper.insertUser(user);
        System.err.println("row="+row);
    }

    @Test
    void getByUsername() {
        User user=mapper.getByUsername("test123");
        System.err.println(user);
    }

    @Test
    void updatePassword() {
        int row=mapper.updatePassword(1,"newpdw","test",new Date());
        System.err.println("row="+row);
    }

    @Test
    void getById() {
        User user=mapper.getById(4);
        System.err.println(user);
    }

    @Test
    void updateInfo() {
        User user=new User();
        user.setId(4);
        user.setPhone("13888888888");
        user.setEmail("123@qq.com");
        user.setGender(1);
        user.setModifiedUser("test123");
        user.setModifiedTime(new Date());
        int row=mapper.updateInfo(user);
        System.err.println("row="+row);
    }
}