package cn.seu.store.mapper;

import cn.seu.store.common.Constant;
import cn.seu.store.entity.Order;
import cn.seu.store.entity.OrderItem;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;
import java.util.List;

@SpringBootTest
class OrderMapperTest {

    @Autowired(required = false)
    OrderMapper mapper;

    @Test
    void listByUid() {
        List<Order> list=mapper.listByUid(1);
        list.forEach(item-> System.err.println(item));
    }

    @Test
    void updateStatus() {
        Integer row=mapper.updateStatus(1,2,"tester",new Date());
        System.err.println("row="+row);
    }

    @Test
    void getById() {
        Order order=mapper.getById(1);
        System.err.println(order);
    }

    @Test
    void insertOrder() {
        Order order=new Order(null,1,"张三","13811112222","福建","漳州","芗城区","闽南师范",1,10000L,null,null, Constant.IS_NOT_DELETE,null,"tester",null,"tester",null);
        Integer row=mapper.insertOrder(order);
        System.err.println("row="+row);
    }

    @Test
    void insertOrderItem() {
        OrderItem item=new OrderItem(null,1,10000001,20,30000L,"testImage","测试商品标题","tester",null,"tester",null);
        Integer row=mapper.insertOrderItem(item);
        System.err.println("row="+row);
    }
}