package cn.seu.store.service.impl;

import cn.seu.store.service.IUserService;
import cn.seu.store.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServiceImplTest {

    @Autowired
    IUserService service;

    @Test
    public void changeAvatar() {
        Integer id=18;
        String avatar="/ccc/3.png";
        String modifiedUser="管理员";
        service.changeAvatar(id, avatar, modifiedUser);
    }

    @Test
    void login() {
        User user=service.login("test12","123456");
        System.err.println(user);
    }

    @Test
    void regist() {
        User user=new User();
        user.setUsername("test1");
        user.setPassword("123456");
        service.regist(user);
    }

    @Test
    void changePassword() {
        service.changePassword("test123","123456","456789","test123");
    }

    @Test
    void findById() {
        User user=service.findById(5);
        System.err.println(user);
    }

    @Test
    void changeInfo() {
        User user=new User();
        user.setPhone("13888887777");
        user.setEmail("12345@qq.com");
        user.setGender(0);
        service.changeInfo(4,"test123",user);
    }
}