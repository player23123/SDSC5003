package cn.seu.store.service.impl;

import cn.seu.store.service.ICartService;
import cn.seu.store.entity.CartVO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class CartServiceImplTest {

    @Autowired
    ICartService service;

    @Test
    void changeNum() {
        service.changeNum(2,-1,1,"tester");
    }

    @Test
    void createCart() {
        service.createCart(10000004,3,1,"abc");
    }

    @Test
    void findByCids() {
        Integer[] cids=new Integer[]{1,8,9,10};
        Integer uid=4;
        List<CartVO> list=service.findByCids(cids,uid);
        list.forEach(item-> System.err.println(item));
    }
}