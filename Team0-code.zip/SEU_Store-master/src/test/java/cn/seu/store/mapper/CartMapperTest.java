package cn.seu.store.mapper;

import cn.seu.store.entity.Cart;
import cn.seu.store.entity.CartVO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;
import java.util.List;

@SpringBootTest
class CartMapperTest {

    @Autowired(required = false)
    CartMapper mapper;

    @Test
    void listByCids() {
        Integer[] cids=new Integer[]{8,9,10};
        List<CartVO> list=mapper.listByCids(cids);
        list.forEach(item-> System.err.println(item));
    }

    @Test
    void listCart() {
        List<CartVO> list=mapper.listCart(4);
        list.forEach(item-> System.err.println(item));
    }

    @Test
    void insertCart() {
        Cart cart=new Cart(null,1,10000001,1000L,1,"tester",null,"tester",null);
        Integer row=mapper.insertCart(cart);
        System.err.println("row="+row);
    }

    @Test
    void updateNum() {
        Integer row=mapper.updateNum(1,3,"tester",new Date());
        System.err.println("row="+row);
    }

    @Test
    void getByUidAndPid() {
        Cart cart=mapper.getByUidAndPid(1,10000001);
        System.err.println(cart);
    }

    @Test
    void listPidByCids() {
        Integer[] cids=new Integer[]{11,12};
        mapper.listPidByCids(cids).forEach(System.err::println);
    }
}