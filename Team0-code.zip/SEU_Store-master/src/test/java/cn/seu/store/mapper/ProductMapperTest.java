package cn.seu.store.mapper;

import cn.seu.store.entity.Product;
import cn.seu.store.entity.ProductCategory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;

@SpringBootTest
class ProductMapperTest {

    @Autowired(required = false)
    ProductMapper mapper;

    @Test
    void updateNumById() {
        Integer row=mapper.updateNumById(10000001,20);
        System.err.println("row="+row);
    }

    @Test
    void getByIdForUpdate() {
        Product product=mapper.getByIdForUpdate(10000001);
        System.err.println(product);
    }

    @Test
    void getCidByPid() {
        System.out.println(mapper.getCidByPid(10000001));
    }

    @Test
    void getCountByCid() {
        Integer count=mapper.getCountByCid(163);
        System.err.println("count="+count);
    }

    @Test
    void listAllByCid() {
        List<Product> list=mapper.listAllByCid(163,1,5);
        list.forEach(item-> System.err.println(item));
    }

    @Test
    void listAllCategory() {
        List<ProductCategory> list=mapper.listAllCategory();
        list.forEach(System.err::println);
    }


    @Test
    void getById() {
        Product product=mapper.getById(10000001);
        System.err.println(product);
    }

    @Test
    void listHotProduct() {
        List<Product> list=mapper.listHotProduct();
        for(Product p:list) {
            System.err.println(p);
        }
    }

    @Test
    void listByCid() {
        mapper.listByCid(163).forEach(System.err::println);
    }

    @Test
    void listCidByPids() {
        Integer[] pids=new Integer[]{10000017,10000041};
        mapper.listCidByPids(Arrays.asList(pids)).forEach(System.err::println);
    }
}