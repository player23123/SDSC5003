package cn.seu.store.service.impl;

import cn.seu.store.entity.Address;
import cn.seu.store.service.IAddressService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class AddressServiceImplTest {

    @Autowired
    IAddressService service;

    @Test
    void createAddress() {
        Address address=new Address(null,
                4,"张三","",350000,"",350600,"",350602,100010,"闽南师范大学",
                "13800000003","010-56778888","学校",1,"test",null,"test",null);
        service.createAddress(4,"test123",address);
    }

    @Test
    void findByUid() {
        List<Address> list=service.findByUid(4);
        list.forEach(System.err::println);
    }

    @Test
    void setDefault() {
        service.setDefault(6,4,"test123");
    }

    @Test
    void removeAddress() {
        service.removeAddress(7,4,"test123");
    }
}