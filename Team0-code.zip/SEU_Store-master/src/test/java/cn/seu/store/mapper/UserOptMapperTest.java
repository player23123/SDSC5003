package cn.seu.store.mapper;

import cn.seu.store.common.Constant;
import cn.seu.store.entity.UserOpt;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;

@SpringBootTest
class UserOptMapperTest {
    @Autowired(required = false)
    UserOptMapper mapper;



    @Test
    void insertOpt() {
        UserOpt opt=new UserOpt(1,2,3, Constant.OPT_TYPE_BUY,null);
        int row=mapper.insertOpt(opt);
        System.out.println("row="+row);
    }

    @Test
    void insertOpts() {
        UserOpt[] arr=new UserOpt[]{
                            new UserOpt(1,2,3,Constant.OPT_TYPE_BUY,null),
                            new UserOpt(3,2,8,Constant.OPT_TYPE_FAV,null),
                            new UserOpt(5,1,2,Constant.OPT_TYPE_CART,null),
                            new UserOpt(12,5,3,Constant.OPT_TYPE_PV,null),
                        };
        int row=mapper.insertOpts(Arrays.asList(arr));
        System.out.println("row="+row);
    }

    @Test
    void getCidByUid() {
        System.err.println(mapper.getCidByUid(4));
    }
}